"""Simple poster figures for a staged LBM pressure/FEM/geometry update.

Run: python make_figures.py
Only recorded files are analysed. No fluid or FEM simulation is run.
Dependencies: numpy, pandas, matplotlib.
"""
from pathlib import Path
from zipfile import ZipFile
from io import BytesIO
import argparse
import hashlib
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch, FancyBboxPatch

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--input', type=Path, default=ROOT / 'input')
parser.add_argument('--out', type=Path, default=ROOT / 'figures')
args = parser.parse_args()
args.out.mkdir(parents=True, exist_ok=True)
TEAL, RUST = '#007A89', '#C44E32'
VOCAL, VENT = '#F1CC91', '#ED9C94'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 14,
    'axes.titlesize': 17, 'axes.titleweight': 'bold', 'axes.labelsize': 14,
    'xtick.labelsize': 12, 'ytick.labelsize': 12,
    'axes.spines.top': False, 'axes.spines.right': False, 'svg.fonttype': 'none'})


def table(archive, name):
    with ZipFile(archive) as z:
        path = next(p for p in z.namelist() if Path(p).name == name)
        return pd.read_csv(BytesIO(z.read(path)))


def text_file(archive, name):
    with ZipFile(archive) as z:
        path = next(p for p in z.namelist() if Path(p).name == name)
        return z.read(path).decode('utf-8-sig')


def save(fig, name):
    fig.savefig(args.out / (name + '.png'), dpi=350, facecolor='white', bbox_inches='tight', pad_inches=.15)
    fig.savefig(args.out / (name + '.svg'), facecolor='white', bbox_inches='tight', pad_inches=.15)
    plt.close(fig)


original_path = args.input / 'original_pressure.zip'
updated_path = args.input / 'deformed_pressure.zip'
fem_path = args.input / 'source_fem_loading.zip'
assert 'gravity=zero to isolate pressure loading' in text_file(fem_path, 'metadata.txt')
text_file(fem_path, 'LOADING_COMPLETE.txt')
text_file(original_path, 'PRESSURE_CHECK_COMPLETE.txt')
text_file(updated_path, 'DEFORMED_AIRFLOW_COMPLETE.txt')
motion = table(fem_path, 'summary.csv')
snapshots = table(fem_path, 'node_snapshots.csv')
nodes0 = table(fem_path, 'initial_nodal_loads.csv')
faces = table(fem_path, 'surface_triangles.csv')
assert np.isclose(motion.t_code.max(), 2.)
assert np.isfinite(motion.select_dtypes(include=np.number)).all().all()
nodes1 = snapshots.loc[np.isclose(snapshots.t_code, 2.)].copy()
assert len(nodes0) == len(nodes1) == 9657


def section(fold, deformed=False):
    """Cut the recorded surface triangles at z=0; no invented geometry."""
    body = (nodes1 if deformed else nodes0)
    xyz = body.loc[body.fold == fold].set_index('node')
    segments = set()
    for ids in faces.loc[faces.fold == fold, ['node0', 'node1', 'node2']].to_numpy(int):
        p = xyz.loc[ids, ['x_mm', 'y_mm', 'z_mm']].to_numpy()
        p[np.abs(p[:, 2]) < 1e-9, 2] = 0
        if np.all(p[:, 2] == 0):
            continue
        hits = []
        for i, j in [(0, 1), (1, 2), (2, 0)]:
            a, b = p[i], p[j]
            if a[2] == 0:
                hits.append(a[:2])
            if a[2] * b[2] < 0:
                hits.append((a - a[2] * (b-a) / (b[2]-a[2]))[:2])
        hits = sorted(set(tuple(np.round(h, 8)) for h in hits))
        if len(hits) == 2 and hits[0] != hits[1]:
            segments.add(tuple(hits))
    adjacency = {}
    for a, b in segments:
        adjacency.setdefault(a, set()).add(b)
        adjacency.setdefault(b, set()).add(a)
    assert adjacency and all(len(v) == 2 for v in adjacency.values())
    remaining, loops = set(adjacency), []
    while remaining:
        start = min(remaining)
        previous, current, loop = None, start, []
        while True:
            loop.append(current)
            remaining.discard(current)
            following = min(p for p in adjacency[current] if p != previous)
            previous, current = current, following
            if current == start:
                break
            assert len(loop) <= len(adjacency)
        loops.append(np.asarray(loop + [loop[0]]))
    return loops


outlines = {deformed: [section(fold, deformed) for fold in range(4)]
            for deformed in [False, True]}
flow0 = table(original_path, 'slice_2_final.csv')
flow1 = table(updated_path, 'slice_2_final.csv')


def field_arrays(frame):
    x, y = np.sort(frame.x_mm.unique()), np.sort(frame.y_mm.unique())
    nx, ny = len(x), len(y)
    assert (nx, ny) == (314, 402)
    fluid = frame.material.isin([1, 5, 6]).to_numpy().reshape(ny, nx)
    speed = np.hypot(frame.ux_lattice, frame.uy_lattice).to_numpy().reshape(ny, nx)
    assert np.isfinite(speed[fluid]).all()
    xe = np.r_[x-.025, x[-1]+.025]
    ye = np.r_[y-.025, y[-1]+.025]
    return xe, ye, fluid, np.ma.masked_where(~fluid, speed)


def anatomy(ax, deformed=False):
    for fold in range(4):
        for loop in outlines[deformed][fold]:
            ax.fill(loop[:, 0], loop[:, 1], facecolor=VOCAL if fold < 2 else VENT,
                    edgecolor='#6B635F', lw=.7, zorder=3)
    ax.set_xlim(-11.5, 11.5)
    ax.set_ylim(-11, 11)
    ax.set_aspect('equal')
    ax.set_xticks([-10, 0, 10])
    ax.set_yticks([-10, 0, 10])
    ax.set_xlabel('Left–right position (mm)')
    ax.set_ylabel('Height (mm)')


# Figure 1: rest-geometry velocity and the pressure PATTERN used for loading.
# This 100 Pa pressure scale is imposed for the FEM loading test; it is not
# a calibration of the fluid solver's physical speed, viscosity or time.
stats0 = table(original_path, 'summary.csv')
stats1 = table(updated_path, 'summary.csv')
r = stats0.loc[(stats0.slice == 2) & (stats0.lbm_step == 6000)].iloc[0]
xe, ye, fluid, speed0 = field_arrays(flow0)
pressure = 100 * (flow0.p_gauge_lattice.to_numpy().reshape(402, 314)
    - r.mean_p_out_lattice) / (r.mean_p_in_lattice - r.mean_p_out_lattice)
pressure = np.ma.masked_where(~fluid, pressure)
fig, axes = plt.subplots(1, 2, figsize=(11.5, 6.4))
fig.subplots_adjust(left=.08, right=.96, top=.88, bottom=.18, wspace=.45)
for ax in axes:
    anatomy(ax)
im0 = axes[0].pcolormesh(xe, ye, pressure, cmap='coolwarm', vmin=-20, vmax=110,
    shading='flat', rasterized=True)
im1 = axes[1].pcolormesh(xe, ye, speed0, cmap='viridis', vmin=0, vmax=.031,
    shading='flat', rasterized=True)
axes[0].set_title('A  Pressure pattern', loc='left', pad=14)
axes[1].set_title('B  Airflow speed', loc='left', pad=14)
axes[0].text(0, -10.65, 'Inlet', ha='center', va='center', fontsize=12)
axes[0].text(0, 10.65, 'Outlet', ha='center', va='center', fontsize=12)
bar = fig.colorbar(im0, ax=axes[0], fraction=.047, pad=.04, ticks=[0, 50, 100])
bar.set_label('Test pressure (Pa)', fontsize=12)
bar = fig.colorbar(im1, ax=axes[1], fraction=.047, pad=.04, ticks=[0, .015, .030])
bar.set_label('Speed (lattice units)', fontsize=12)
fig.legend(handles=[Patch(facecolor=VOCAL, label='Vocal folds'),
    Patch(facecolor=VENT, label='Ventricular folds')], loc='lower center',
    bbox_to_anchor=(.5, .015), ncol=2, frameon=False, fontsize=13)
save(fig, 'initial_airflow')

# Figure 2: the mechanical response and the actual geometry fed back to LBM.
# At each time, take the maximum nodal displacement norm across each pair
# of folds. These are not lateral amplitudes or bilateral nodal averages.
vocal_peak = motion[['vocal_left_max_displacement_mm', 'vocal_right_max_displacement_mm']].max(axis=1)
vent_peak = motion[['ventricular_left_max_displacement_mm', 'ventricular_right_max_displacement_mm']].max(axis=1)
motion_values = pd.DataFrame({'t_code': motion.t_code,
    'maximum_vocal_displacement_mm': vocal_peak,
    'maximum_ventricular_displacement_mm': vent_peak})
motion_values.to_csv(args.out / 'fem_response_values.csv', index=False)
fig, axes = plt.subplots(1, 2, figsize=(12, 5.6))
fig.subplots_adjust(left=.09, right=.98, top=.86, bottom=.21, wspace=.34)
axes[0].plot(motion.t_code, vocal_peak, lw=2.7, color=TEAL, label='Vocal folds')
axes[0].plot(motion.t_code, vent_peak, lw=2.7, color=RUST, ls='--', label='Ventricular folds')
axes[0].set_title('A  Movement under pressure', loc='left', pad=14)
axes[0].set_xlabel('Simulation time (code units)', labelpad=9)
axes[0].set_ylabel('Maximum nodal displacement (mm)')
axes[0].set_xlim(0, 2)
axes[0].set_ylim(0, .09)
axes[0].grid(axis='y', color='#E5E8EB', lw=.8)
axes[0].set_axisbelow(True)
axes[0].legend(frameon=False, fontsize=12)
for deformed, color, style, label in [(False, '#66717B', '--', 'Initial'),
                                    (True, TEAL, '-', 'Deformed')]:
    first = True
    for fold in [0, 1]:
        for loop in outlines[deformed][fold]:
            axes[1].plot(loop[:, 0], loop[:, 1], color=color, ls=style, lw=2,
                label=label if first else None)
            first = False
axes[1].set_xlim(-.85, .85)
axes[1].set_ylim(-2.8, -1.3)
axes[1].set_aspect('equal')
axes[1].set_title('B  Updated geometry: close-up', loc='left', pad=14)
axes[1].set_xlabel('Left–right position (mm)', labelpad=9)
axes[1].set_ylabel('Height (mm)')
axes[1].legend(frameon=False, fontsize=12, loc='lower center')
save(fig, 'pressure_response_and_geometry')

# A simple insertable load table. Summing vectors FIRST and taking their norm
# gives resultant magnitude. Fixed-node requested loads remain included.
updated_loads = pd.read_csv(args.input / 'updated_nodal_loads.csv')
force_columns = ['full_fx_microN', 'full_fy_microN', 'full_fz_microN']
old_resultants = nodes0.groupby('fold')[force_columns].sum().to_numpy()
new_resultants = updated_loads.groupby('fold')[force_columns].sum().to_numpy()
old_norm = np.linalg.norm(old_resultants, axis=1)
new_norm = np.linalg.norm(new_resultants, axis=1)
change = 100 * (new_norm / old_norm - 1)
names = ['Vocal left', 'Vocal right', 'Ventricular left', 'Ventricular right']
loads = pd.DataFrame({'fold': names, 'initial_resultant_mN': old_norm/1000,
    'updated_resultant_mN': new_norm/1000, 'change_percent': change})
loads.to_csv(args.out / 'load_change_table.csv', index=False)
fig, ax = plt.subplots(figsize=(10, 2.8))
ax.axis('off')
cells = [[name, f'{old/1000:.4f}', f'{new/1000:.4f}', f'{delta:+.2f}%']
    for name, old, new, delta in zip(names, old_norm, new_norm, change)]
tab = ax.table(cellText=cells, colLabels=['Fold', 'Initial load (mN)', 'Updated load (mN)', 'Change'],
    cellLoc='center', loc='center', colWidths=[.31, .25, .27, .17])
tab.auto_set_font_size(False)
tab.set_fontsize(14)
tab.scale(1, 1.8)
for (row, col), cell in tab.get_celld().items():
    cell.set_edgecolor('white')
    if row == 0:
        cell.set_facecolor('#D8E7F3')
        cell.set_text_props(weight='bold')
    else:
        cell.set_facecolor('#F1F4F6' if row % 2 else '#FFFFFF')
fig.subplots_adjust(left=.02, right=.98, bottom=.03, top=.97)
save(fig, 'load_change_table')

# Supplement: fields before/after the geometry update, on a shared speed scale.
fig, axes = plt.subplots(1, 2, figsize=(11.5, 6.4))
fig.subplots_adjust(left=.08, right=.91, top=.88, bottom=.15, wspace=.28)
for ax, frame, deformed, title in [(axes[0], flow0, False, 'Initial geometry'),
                                 (axes[1], flow1, True, 'Deformed geometry')]:
    xe1, ye1, _, speed = field_arrays(frame)
    anatomy(ax, deformed)
    image = ax.pcolormesh(xe1, ye1, speed, cmap='viridis', vmin=0, vmax=.031,
        shading='flat', rasterized=True)
    ax.set_title(title, loc='left', pad=14)
cax = fig.add_axes([.925, .28, .018, .43])
bar = fig.colorbar(image, cax=cax, ticks=[0, .015, .030])
bar.set_label('Speed (lattice units)', fontsize=12)
save(fig, 'supplement_airflow_update')

# Optional concept strip; no arrow implies a continuous time-marching loop.
fig, ax = plt.subplots(figsize=(12, 2.1))
ax.set_xlim(0, 12)
ax.set_ylim(0, 2)
ax.axis('off')
steps = ['1  Airflow in\ninitial geometry', '2  Pressure loading\nand FEM movement',
         '3  Airflow in\ndeformed geometry', '4  Updated\nsurface loads']
for i, label in enumerate(steps):
    left = .08 + i*3
    ax.add_patch(FancyBboxPatch((left, .45), 2.62, 1.1,
        boxstyle='round,pad=0.03,rounding_size=0.1', fc='#E1EEF6', ec='none'))
    ax.text(left+1.31, 1, label, ha='center', va='center', fontsize=17)
    if i < 3:
        ax.annotate('', xy=(left+2.91, 1), xytext=(left+2.66, 1),
            arrowprops={'arrowstyle': '->', 'lw': 1.8, 'color': TEAL})
fig.subplots_adjust(left=.01, right=.99, bottom=.01, top=.99)
save(fig, 'staged_sequence')

endpoint0 = stats0.loc[stats0.lbm_step == 6000].sort_values('slice')
endpoint1 = stats1.loc[stats1.lbm_step == 6000].sort_values('slice')
jet_change = 100*(endpoint1.max_speed_lattice.to_numpy()/endpoint0.max_speed_lattice.to_numpy()-1)
pd.DataFrame({'slice': [1, 2, 3], 'z_mm': endpoint0.z_mm.to_numpy(),
    'initial_peak_speed_lattice': endpoint0.max_speed_lattice.to_numpy(),
    'updated_peak_speed_lattice': endpoint1.max_speed_lattice.to_numpy(),
    'peak_speed_change_percent': jet_change}).to_csv(args.out/'airflow_change_values.csv', index=False)
result = {'operation': 'analysis of recorded files; no CFD or FEM solve',
    'peak_vocal_nodal_displacement_mm': float(vocal_peak.max()),
    'peak_ventricular_nodal_displacement_mm': float(vent_peak.max()),
    'geometry_for_update_t_code': 2., 'deformation_magnification': 1,
    'load_pressure_normalisation_Pa': 100., 'gravity_in_loading_test': 0,
    'comparison_lattice_step': 6000, 'flow_converged': False,
    'peak_jet_speed_change_percent': jet_change.tolist(),
    'resultant_load_change_percent': change.tolist(),
    'loads_include_fixed_nodes': True,
    'pressure_and_load_surface_geometry_both_updated': True,
    'continuous_FSI_demonstrated_by_staged_sequence': False,
    'sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
        for p in [original_path, updated_path, fem_path, args.input/'updated_nodal_loads.csv']}}
with (args.out/'figure_values.json').open('w') as stream:
    json.dump(result, stream, indent=2)
print(json.dumps(result, indent=2))
