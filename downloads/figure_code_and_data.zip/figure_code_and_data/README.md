# Reproduce the staged figures

Install Python with NumPy, pandas and Matplotlib.

```
python -m pip install numpy pandas matplotlib
python make_figures.py
```

The script reads the recorded files in input/ and writes figures/ with PNG/SVG plots, CSV values and a JSON summary. It does not run a fluid or FEM simulation.

To regenerate the prepared updated nodal loads from the recordings:

```
python prepare_updated_loads.py
python make_figures.py
```

These are gravity-off, staged pressure/FEM/geometry tests. Pressure patterns are normalised to a chosen 100 Pa loading scale, not physically calibrated airflow pressure. The fixed flow fields are developing after 6,000 steps. Resultant requested pressure loads include fixed-node loads; the updated map changes both pressure and surface geometry. Three 2D slices are not full 3D flow. This sequence is not continuous moving-boundary FSI or sustained phonation.

FEM geometry/mechanics derive from Yong's model builders. Flow uses the separate AI-assisted D2Q9 diagnostic, not unchanged Kummerlaender/Moisik source. The original prototype remains part of the project's provenance.
