#!/usr/bin/env python3
"""Recorded-pressure surface integration only. No CFD or FEM solve.

Pressure field 1 and areas/normals on recorded geometry G1 define loads F1.
The next FEM response test starts at the same G0/rest state as test 0.
"""
from pathlib import Path
import csv
import hashlib
import io
import json
import math
import zipfile
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
INPUT, REVIEW = ROOT/"input", ROOT/"review"
NAMES = ("vocal_left", "vocal_right", "ventricular_left", "ventricular_right")
EXPECTED = {"source_fem_loading.zip": "beb95173ed94410ff9157598328ea04078e205739c5b9b5d88aae3f78c295cce",
            "original_pressure.zip": "44e41a7404432bf66624a633dec50f9fda4869601bc85fe12725fb2f79b4e315",
            "deformed_pressure.zip": "a0f79687cc5ff3cf9c990c7a46ce386846af98adc3e71aebc2abfccb51297ffd"}
EPS, TARGET = 1e-8, 100.0


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_csv(z, name):
    return pd.read_csv(io.BytesIO(z.read(name)))


class Pressure:
    def __init__(self, path):
        with zipfile.ZipFile(path) as z:
            summary = read_csv(z, "summary.csv")
            self.fields, self.fluid, self.ends = [], [], []
            for s in range(1, 4):
                row = summary[(summary["slice"] == s) & (summary.lbm_step == 6000)]
                assert len(row) == 1
                row = row.iloc[0]
                self.ends.append((float(row.mean_p_in_lattice), float(row.mean_p_out_lattice)))
                f = read_csv(z, f"slice_{s}_final.csv")
                assert len(f) == 314*402
                self.fields.append(f.p_gauge_lattice.to_numpy())
                self.fluid.append(f.material.isin((1, 5, 6)).to_numpy())

    def sample(self, s, x, y):
        gx, gy = (x+7.825)/0.05, (y+10.025)/0.05
        i, j = math.floor(gx), math.floor(gy)
        tx, ty = gx-i, gy-j
        value, weight = 0.0, 0.0
        for dj in range(2):
            for di in range(2):
                ii, jj = i+di, j+dj
                if not (0 <= ii < 314 and 0 <= jj < 402):
                    continue
                a = jj*314+ii
                w = (1-tx if di == 0 else tx)*(1-ty if dj == 0 else ty)
                if self.fluid[s][a] and w > 0:
                    value += w*self.fields[s][a]
                    weight += w
        if weight <= 1e-12:
            return float("nan")
        pin, pout = self.ends[s]
        return TARGET*((value/weight)-pout)/(pin-pout)


def clip(poly, axis, bound, greater):
    if not poly:
        return []
    out = []
    previous = poly[-1]
    dp = (previous[axis]-bound)*(1 if greater else -1)
    for current in poly:
        dc = (current[axis]-bound)*(1 if greater else -1)
        pin, cin = dp >= -EPS, dc >= -EPS
        if pin != cin:
            t = min(1, max(0, dp/(dp-dc)))
            out.append(previous+t*(current-previous))
        if cin:
            out.append(current)
        previous, dp = current, dc
    return out


def integrate(nodes0, geometry, faces, pressure, quad_path=None):
    forces = {key: np.zeros(3) for key in nodes0}
    areas = {key: 0.0 for key in nodes0}
    parea = {key: 0.0 for key in nodes0}
    candidate, sampled = np.zeros((4, 3)), np.zeros((4, 3))
    totals = np.zeros((4, 3))
    qfile = quad_path.open("w", newline="", encoding="utf-8") if quad_path else None
    writer = csv.writer(qfile) if qfile else None
    if writer:
        writer.writerow("fold,source_triangle,slice,area_mm2,cx_mm,cy_mm,cz_mm,pressure_Pa,nx,ny,nz,node0,node1,node2,N0,N1,N2".split(","))
    for row in faces.itertuples(index=False):
        f, tid = int(row.fold), int(row.triangle)
        ids = (int(row.node0), int(row.node1), int(row.node2))
        ref = np.array([nodes0[f, n] for n in ids])
        # Identify excluded attachments and AP endcaps from original topology.
        # Deformed end faces need not remain at z = +/-7.
        if any(np.max(np.abs(ref[:, axis]-value)) <= EPS
               for axis, value in ((2, -7), (2, 7), (0, -7.8), (0, 7.8))):
            continue
        xyz = np.array([geometry[f, n] for n in ids])
        normal = np.cross(xyz[1]-xyz[0], xyz[2]-xyz[0])
        twice = np.linalg.norm(normal)
        assert twice > 1e-12
        normal /= twice
        nxy = math.hypot(normal[0], normal[1])
        if nxy < 1e-10:
            continue
        poly = list(np.column_stack([xyz, np.eye(3)]))
        poly = clip(clip(poly, 0, -7.8, True), 0, 7.8, False)
        for s in range(3):
            band = clip(clip(poly, 2, -7+s*14/3, True), 2, -7+(s+1)*14/3, False)
            for k in range(1, len(band)-1):
                tri = np.array([band[0], band[k], band[k+1]])
                area = np.linalg.norm(np.cross(tri[1, :3]-tri[0, :3], tri[2, :3]-tri[0, :3]))/2
                if area < 1e-12:
                    continue
                candidate[f, s] += area
                centre = tri.mean(axis=0)
                p = float("nan")
                for cells in (0.75, 1.25, 1.75):
                    p = pressure.sample(s, centre[0]+cells*0.05*normal[0]/nxy,
                                        centre[1]+cells*0.05*normal[1]/nxy)
                    if math.isfinite(p):
                        break
                if not math.isfinite(p):
                    continue
                sampled[f, s] += area
                totals[f] += -p*area*normal
                assert abs(sum(centre[3:])-1) < 1e-10 and min(centre[3:]) > -1e-10
                for local, n in enumerate(ids):
                    a = area*centre[3+local]
                    areas[f, n] += a
                    parea[f, n] += p*a
                    forces[f, n] += -p*a*normal
                if writer:
                    writer.writerow([f, tid, s+1, area, *centre[:3], p, *normal, *ids, *centre[3:]])
    if qfile:
        qfile.close()
    assert (sampled.sum(axis=1)/candidate.sum(axis=1) >= 0.995).all(), "Insufficient pressure sampling coverage"
    for f in range(4):
        nodal_sum = np.sum([v for (fold, _), v in forces.items() if fold == f], axis=0)
        assert np.linalg.norm(nodal_sum-totals[f]) < 1e-8*max(1, np.linalg.norm(totals[f]))
    return forces, areas, parea, candidate, sampled, totals


def main():
    REVIEW.mkdir(exist_ok=True)
    for name, expected in EXPECTED.items():
        assert sha(INPUT/name) == expected, f"Source hash mismatch: {name}"
    with zipfile.ZipFile(INPUT/"source_fem_loading.zip") as z:
        original = read_csv(z, "initial_nodal_loads.csv")
        snapshots = read_csv(z, "node_snapshots.csv")
        faces = read_csv(z, "surface_triangles.csv")
        assert "LOADING_COMPLETE.txt" in z.namelist()
        (INPUT/"surface_triangles.csv").write_bytes(z.read("surface_triangles.csv"))
    nodes0 = {(int(r.fold), int(r.node)): np.array([r.x_mm, r.y_mm, r.z_mm])
              for r in original.itertuples(index=False)}
    final = snapshots[snapshots.t_code == 2]
    geometry = {(int(r.fold), int(r.node)): np.array([r.x_mm, r.y_mm, r.z_mm])
                for r in final.itertuples(index=False)}
    assert set(nodes0) == set(geometry) and len(nodes0) == 9657
    p0, p1 = Pressure(INPUT/"original_pressure.zip"), Pressure(INPUT/"deformed_pressure.zip")
    reproduction = integrate(nodes0, nodes0, faces, p0)
    old_forces = {(int(r.fold), int(r.node)): np.array([r.full_fx_microN, r.full_fy_microN, r.full_fz_microN])
                  for r in original.itertuples(index=False)}
    reproduce_error = max(float(np.max(np.abs(reproduction[0][key]-old_forces[key]))) for key in nodes0)
    assert reproduce_error < 1e-5, f"Original Java map reproduction error: {reproduce_error} microN"
    updated = integrate(nodes0, geometry, faces, p1, INPUT/"load_quadrature.csv")
    forces, areas, parea, candidate, sampled, totals = updated
    output = []
    for r in original.itertuples(index=False):
        key = int(r.fold), int(r.node)
        area = areas[key]
        output.append({"fold": key[0], "node": key[1], "dynamic": bool(r.dynamic),
                       "x_mm": r.x_mm, "y_mm": r.y_mm, "z_mm": r.z_mm,
                       "area_weight_mm2": area, "area_weighted_pressure_Pa": parea[key]/area if area else 0,
                       "full_fx_microN": forces[key][0], "full_fy_microN": forces[key][1], "full_fz_microN": forces[key][2]})
    pd.DataFrame(output).to_csv(INPUT/"updated_nodal_loads.csv", index=False)
    checks, force_rows = [], []
    for f in range(4):
        old_total = np.sum([v for (fold, _), v in old_forces.items() if fold == f], axis=0)
        for s in range(3):
            checks.append({"fold": f, "slice": s+1, "candidate_area_mm2": candidate[f, s],
                           "sampled_area_mm2": sampled[f, s], "unsampled_area_mm2": candidate[f, s]-sampled[f, s]})
        force_rows.append({"fold": f, "name": NAMES[f], "old_Fx_microN": old_total[0],
                           "old_Fy_microN": old_total[1], "old_Fz_microN": old_total[2],
                           "updated_Fx_microN": totals[f, 0], "updated_Fy_microN": totals[f, 1], "updated_Fz_microN": totals[f, 2],
                           "old_resultant_norm_microN": float(np.linalg.norm(old_total)),
                           "updated_resultant_norm_microN": float(np.linalg.norm(totals[f])),
                           "resultant_norm_change_percent": float(100*(np.linalg.norm(totals[f])/np.linalg.norm(old_total)-1)),
                           "loaded_nodes": int(sum(areas[key] > 0 for key in nodes0 if key[0] == f)),
                           "candidate_area_mm2": candidate[f].sum(), "sampled_area_mm2": sampled[f].sum()})
    pd.DataFrame(checks).to_csv(INPUT/"mapping_checks.csv", index=False)
    pd.DataFrame(force_rows).to_csv(REVIEW/"force_update_summary.csv", index=False)
    result = {"operation": "pressure quadrature on recorded meshes only; no CFD or FEM solve",
              "source_sha256": EXPECTED, "pressure_normalisation_Pa": TARGET,
              "mapping_geometry": "recorded G1 at FEM t_code=2.0; initial attachment/endcap face exclusions retained",
              "FEM_test_initial_state": "G0, original rest configuration and zero velocity, same as first loading test",
              "interpretation": "separate controlled response to updated geometry-derived load; not a dynamic continuation",
              "original_Java_nodal_map_reproduction_max_abs_error_microN": reproduce_error,
              "folds": force_rows,
              "force_note": "Full requested resultants include forces assigned to fixed nodes; not net force after constraints or contact.",
              "updated_pressure_and_surface_geometry_both_change": True}
    (REVIEW/"force_update_summary.json").write_text(json.dumps(result, indent=2)+"\n")
    (INPUT/"load_manifest.json").write_text(json.dumps(result, indent=2)+"\n")
    paths = sorted(p for p in INPUT.rglob("*") if p.is_file() and p.name != "inputs.sha256")
    (INPUT/"inputs.sha256").write_text("".join(f"{sha(p)}  {p.relative_to(INPUT).as_posix()}\n" for p in paths))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
