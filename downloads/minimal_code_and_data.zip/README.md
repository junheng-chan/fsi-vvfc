# Selected code and numerical records

This small supplement contains selected source files and compact numerical records for the exploratory trials. It excludes plotting scripts, large raw mesh/fluid snapshots, whole-run archives, compiled classes and an ArtiSynth installation. The code is supplied for inspection and is not a standalone runnable project; existing Yong FEM builders and the matching ArtiSynth/JOGL environment are required. No simulation was run to prepare this supplement.

## Contents
- code/transientfsi/: the eight Java/compute-shader module files from the launcher-corrected transient setup, plus run.properties.
- code/gravity/: the frozen-pressure gravity controller and its properties. Supporting dependencies are not duplicated.
- data/coupled.csv and oneway.csv: accepted derived histories, with their original column names and no resampling or smoothing.
- data/gravity_contact_summary.csv: condensed metrics from the frozen-pressure gravity/contact recording.
- data/transient_review.json: matched-run checks, endpoints, stops, contact summaries and original recording hashes.
- data/settings/: the recorded metadata for each trial.

## Interpretation
The frozen-pressure gravity test recomputed no airflow during movement. It reached 5 code units and recorded first load-bearing vocal-ventricular contact at 0.45 (right) and 0.46 (left). It is separate from the moving-boundary comparison.

In the coupled run, fluid geometry, wall velocity and pressure-load mapping follow FEM movement. In the one-way run the fluid boundaries and mapping stay at the initial geometry, but evolving pressure still loads the moving FEM. This comparison does not isolate airflow against gravity alone.

For the chart, use t_code <= 0.4. The chart averages the left and right ventricular means with equal weight; descent is minus mean_ventricular_free_node_vertical_mm. Pressure is mean_ventricular_pressure_Fy_mN (upwards positive). These are nodal averages, not volume-weighted tissue movement, and requested pressure resultants include fixed-node loads. The interval was selected after inspecting the coupled failure, before receiving the control results. At 0.4 code, descent is 0.538139657075 mm (coupled) and 0.557900084085 mm (one-way).

The coupled recording ends at 0.650; the next fluid state was rejected by the density guard and was not loaded onto the FEM. The one-way recording ends at 0.485 because predicted node motion exceeded half a fluid cell per exchange. Later run durations differ and should not be treated as matched endpoints.

Times remain in model code units. The adopted 0.01 s/code conversion is historically unverified. Legacy gravity -9.8 code corresponds to -98 m/s^2 under that convention, not calibrated Earth gravity. Both transient runs use elevated effective viscosity, pressure-only loading, three independent 2D slices, explicit lagged exchange and non-mass-conserving cell refill. No convergence or physiological validation, sustained oscillation or causal damping result is established.

## Provenance
Geometry and tissue mechanics build on Yong's FEM. The original preview used Kummerlaender's prototype and Scott R. Moisik's Java integration. The later solver, GPU driver and coupling workflow are a separate AI-assisted implementation developed with OpenAI's ChatGPT for coding and debugging. These excerpts must not be represented as unchanged Kummerlaender/Moisik source.
