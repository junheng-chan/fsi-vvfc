package artisynth.models.vocVent.gravity;

import java.awt.Color;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Properties;

import artisynth.core.femmodels.FemModel3d;
import artisynth.core.femmodels.FemNode3d;
import artisynth.core.femmodels.FemModel.SurfaceRender;
import artisynth.core.mechmodels.CollisionBehavior;
import artisynth.core.mechmodels.MechModel;
import artisynth.core.modelbase.ControllerBase;
import artisynth.core.modelbase.MonitorBase;
import artisynth.core.modelbase.RenderableComponentBase;
import artisynth.core.workspace.DriverInterface;
import artisynth.core.workspace.RootModel;
import artisynth.models.vocVent.baseline.VocalFoldBuilder;
import artisynth.models.vocVent.baseline.VentFoldBuilder;
import maspack.matrix.Point3d;
import maspack.matrix.RigidTransform3d;
import maspack.matrix.Vector3d;
import maspack.render.RenderProps;
import maspack.render.Renderer;

/** Frozen LBM pressure loads plus the original model gravity parameter.
 * Records descent and actual collision forces. No fluid stepping within this FEM run. */
public class VocVentGravityContact extends RootModel {
   private static final String[] NAMES={"vocal_left","vocal_right","ventricular_left","ventricular_right"};
   private final FemModel3d[] folds=new FemModel3d[4];
   private final FemNode3d[] reference=new FemNode3d[2];
   private SurfaceLoadMap map;
   private Path output;
   private PrintWriter summary,snapshots;
   private double targetPa,ramp,end,maxDisplacement;
   private double appliedScale,commandT0,commandT1;
   private double lastRecorded=-1;
   private int nextSnapshot;
   private boolean finished;
   private ContactRecorder contact;
   private double gravityY,lastSnapshot=-1;

   @Override public void build(String[] args) throws IOException {
      super.build(args);
      Properties config=new Properties();
      try(java.io.InputStream in=Files.newInputStream(directory().resolve("load.properties"))) { config.load(in); }
      targetPa=number(config,"pressure_difference_Pa"); ramp=number(config,"ramp_duration_code");
      end=number(config,"end_time_code"); maxDisplacement=number(config,"max_displacement_mm");
      double maxStep=number(config,"max_step_code");
      gravityY=number(config,"gravity_y_code");
      if(targetPa<=0 || ramp<=0 || end<=2 || maxStep<=0 || maxDisplacement<=0)
         throw new IOException("Invalid loading parameters");
      Path source=directory().resolve(config.getProperty("pressure_snapshot_zip"));
      verifySource(source,"44e41a7404432bf66624a633dec50f9fda4869601bc85fe12725fb2f79b4e315");
      PressureSnapshot pressure=new PressureSnapshot(source,targetPa);
      MechModel mech=new MechModel("mech"); mech.setGravity(0,gravityY,0); mech.setMaxStepSize(maxStep); addModel(mech);
      VocalFoldBuilder vb=new VocalFoldBuilder(); VentFoldBuilder eb=new VentFoldBuilder();
      folds[0]=vb.buildFem(false); folds[1]=vb.buildFem(true);
      folds[2]=eb.buildFem(false); folds[3]=eb.buildFem(true);
      for(int f=0;f<4;f++) {
         // Preserve Yong's lateral fixation; leave the AP ends free, as supplied.
         for(FemNode3d n:folds[f].getNodes()) if(Math.abs(n.getPosition().x)<1e-7) n.setDynamic(false);
         folds[f].transformGeometry(new RigidTransform3d((f%2==0?-1:1)*(f<2?7.8:10.8),f<2?0:0.5,0));
         folds[f].setSurfaceRendering(SurfaceRender.Shaded);
         RenderProps.setFaceColor(folds[f],f<2?new Color(249,212,160):new Color(249,150,140));
         RenderProps.setAlpha(folds[f],1.0); RenderProps.setLineWidth(folds[f],0);
         folds[f].setGravity(0,gravityY,0);
         folds[f].setAbortOnInvertedElements(true);
         mech.addModel(folds[f]);
         System.out.println("GRAVITY FEM "+NAMES[f]+": "+folds[f].getGravity());
      }
      mech.setCollisionBehavior(folds[0],folds[1],new CollisionBehavior(true,0.5));
      mech.setCollisionBehavior(folds[0],folds[2],new CollisionBehavior(true,0));
      mech.setCollisionBehavior(folds[1],folds[3],new CollisionBehavior(true,0));
      output=Paths.get("gravity_contact_results","run_"+new SimpleDateFormat("yyyyMMdd_HHmmss_SSS").format(new Date())).toAbsolutePath();
      Files.createDirectories(output);
      try(PrintWriter q=writer("load_quadrature.csv"); PrintWriter t=writer("surface_triangles.csv"); PrintWriter c=writer("mapping_checks.csv")) {
         map=new SurfaceLoadMap(folds,pressure,q,t,c);
      }
      verifyInitialSeparation();
      contact=new ContactRecorder(mech,folds,map,output);
      System.out.println("GRAVITY CONTACT RECORDER v2: legacy inContact bypassed; geometric evidence and force records used.");
      reference[0]=chooseReference(folds[0],true); reference[1]=chooseReference(folds[1],false);
      writeInitialLoads(); writeMetadata(source,pressure,maxStep);
      summary=writer("summary.csv"); snapshots=writer("node_snapshots.csv");
      summary.println("t_code,t_ms_declared,command_t0,command_t1,command_matches_interval,load_fraction,left_ref_node,right_ref_node,left_dx_mm,left_dy_mm,left_dz_mm,right_dx_mm,right_dy_mm,right_dz_mm,reference_x_separation_mm,vocal_left_max_displacement_mm,vocal_right_max_displacement_mm,ventricular_left_max_displacement_mm,ventricular_right_max_displacement_mm");
      snapshots.println("t_code,fold,node,x_mm,y_mm,z_mm,dx_mm,dy_mm,dz_mm,requested_fx_microN,requested_fy_microN,requested_fz_microN,vx_code,vy_code,vz_code");
      addController(new ControllerBase() {
         @Override public void apply(double t0,double t1) {
            if(finished) { setStopRequest(true); return; }
            if(t0<lastRecorded-1e-9) {
               fail(new IllegalStateException("Reload for a fresh run; rewinding is unsupported"),t0);
               return;
            }
            commandT0=t0; commandT1=t1;
            double t=(t0+t1)*0.5;
            appliedScale=t>=ramp?1:0.5*(1-Math.cos(Math.PI*Math.max(0,t)/ramp));
            Vector3d force=new Vector3d();
            for(SurfaceLoadMap.NodeLoad nl:map.nodes) { force.scale(appliedScale,nl.force); nl.node.setExternalForce(force); }
         }
      });
      addMonitor(new MonitorBase() {
         @Override public void apply(double t0,double t1) {
            if(finished) { setStopRequest(true); return; }
            try {
               if(t1<lastRecorded-1e-9) throw new IOException("Reload for a fresh run; rewinding is unsupported");
               double peak=record(t1,Math.abs(t0-commandT0)<1e-9 && Math.abs(t1-commandT1)<1e-9);
               boolean firstVVContact=contact.record(t1);
               if(firstVVContact) snapshot(t1);
               double[] times={ramp,2.0,end};
               if(nextSnapshot<times.length && t1>=times[nextSnapshot]-1e-9) { snapshot(t1); nextSnapshot++; }
               if(!Double.isFinite(peak) || peak>maxDisplacement)
                  throw new IOException("Displacement exceeded the gravity-test limit "+maxDisplacement+" mm");
               if(t1>=end-1e-9) {
                  contact.finish(); contact.close();
                  finished=true; summary.close(); snapshots.close(); setStopRequest(true);
                  Files.write(output.resolve("GRAVITY_CONTACT_COMPLETE.txt"),"Gravity and frozen pressure loading test complete. Consult contact_summary.csv; completion does not imply contact occurred.\n".getBytes(StandardCharsets.UTF_8));
                  System.out.println("GRAVITY CONTACT CHECK COMPLETE: "+output);
               }
            } catch(IOException | RuntimeException e) { fail(e,t1); }
         }
      });
      addRenderable(new LoadArrows());
      addRenderable(contact.overlay());
      record(0,true); contact.record(0); snapshot(0);
      System.out.printf(Locale.ROOT,"GRAVITY reference nodes: left=%d, right=%d%n",reference[0].getNumber(),reference[1].getNumber());
      System.out.printf(Locale.ROOT,"GRAVITY LOAD SCALE: pressure pattern normalised to %.3f Pa; forces in microN%n",targetPa);
      System.out.printf(Locale.ROOT,"GRAVITY: vector [0, %.6f, 0] code; original-model value is -9.8%n",gravityY);
      System.out.printf(Locale.ROOT,"GRAVITY UNIT NOTE: %.6f m/s2 downward under the adopted 0.01 s/code convention; historical physical units unverified%n",-10*gravityY);
      System.out.printf(Locale.ROOT,"GRAVITY RUN LIMITS: end %.3f code; displacement guard %.3f mm%n",end,maxDisplacement);
      System.out.println("GRAVITY CONTACT READY: leave paused to inspect; Play begins the gravity/contact test.");
      System.out.println("GRAVITY output: "+output);
   }

   private static Path directory() throws IOException {
      try {
         Path classes=Paths.get(VocVentGravityContact.class.getProtectionDomain().getCodeSource().getLocation().toURI());
         return classes.getParent();
      } catch(java.net.URISyntaxException e) { throw new IOException(e); }
   }

   private void verifyInitialSeparation() throws IOException {
      double[] minX={1e100,1e100,1e100,1e100},maxX={-1e100,-1e100,-1e100,-1e100};
      double[] minY={1e100,1e100,1e100,1e100},maxY={-1e100,-1e100,-1e100,-1e100};
      for(int f=0;f<4;f++) for(FemNode3d n:folds[f].getNodes()) {
         Point3d p=n.getPosition();
         minX[f]=Math.min(minX[f],p.x); maxX[f]=Math.max(maxX[f],p.x);
         minY[f]=Math.min(minY[f],p.y); maxY[f]=Math.max(maxY[f],p.y);
      }
      double vocal=minX[1]-maxX[0],left=minY[2]-maxY[0],right=minY[3]-maxY[1];
      System.out.printf(Locale.ROOT,"GRAVITY INITIAL CLEARANCE: vocal x bounds %.6f mm; left vocal-ventricular y bounds %.6f mm; right %.6f mm%n",vocal,left,right);
      if(!(vocal>0 && left>0 && right>0))
         throw new IOException("Expected separated initial meshes; check geometry before running");
   }
   private static void verifySource(Path source,String expected) throws IOException {
      try {
         StringBuilder b=new StringBuilder();
         for(byte v:MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(source))) b.append(String.format(Locale.ROOT,"%02x",v&255));
         if(!b.toString().equals(expected)) throw new IOException("Unexpected pressure source bytes");
      } catch(java.security.NoSuchAlgorithmException e) { throw new IOException(e); }
   }

   private static double number(Properties p,String key) throws IOException {
      try { double v=Double.parseDouble(p.getProperty(key)); if(Double.isFinite(v)) return v; }
      catch(RuntimeException ignored) { }
      throw new IOException("Invalid property "+key);
   }

   private FemNode3d chooseReference(FemModel3d f,boolean left) {
      double edge=left?Double.NEGATIVE_INFINITY:Double.POSITIVE_INFINITY;
      for(FemNode3d n:f.getNodes()) edge=left?Math.max(edge,n.getPosition().x):Math.min(edge,n.getPosition().x);
      FemNode3d best=null;
      for(FemNode3d n:f.getNodes()) if(Math.abs(n.getPosition().x-edge)<0.05) {
         if(best==null) { best=n; continue; }
         Point3d p=n.getPosition(),b=best.getPosition(); double d=Math.abs(p.z)-Math.abs(b.z);
         if(d< -1e-9 || (Math.abs(d)<=1e-9 && (left?p.x>b.x:p.x<b.x))) best=n;
      }
      if(best==null) throw new IllegalStateException("No medial reference node");
      return best;
   }

   private double record(double time,boolean matches) throws IOException {
      double[] peak=new double[4];
      for(SurfaceLoadMap.NodeLoad nl:map.nodes) {
         double d=nl.node.getPosition().distance(nl.initial);
         if(!Double.isFinite(d)) throw new IOException("Invalid FEM position");
         peak[nl.fold]=Math.max(peak[nl.fold],d);
      }
      Vector3d l=new Vector3d(),r=new Vector3d();
      l.sub(reference[0].getPosition(),map.byNode.get(reference[0]).initial);
      r.sub(reference[1].getPosition(),map.byNode.get(reference[1]).initial);
      summary.printf(Locale.ROOT,"%.12g,%.12g,%.12g,%.12g,%s,%.12g,%d,%d,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g%n",
         time,10*time,commandT0,commandT1,matches,appliedScale,reference[0].getNumber(),reference[1].getNumber(),
         l.x,l.y,l.z,r.x,r.y,r.z,reference[1].getPosition().x-reference[0].getPosition().x,peak[0],peak[1],peak[2],peak[3]);
      summary.flush(); if(summary.checkError()) throw new IOException("Cannot write loading summary");
      if((int)Math.floor(time*10)>(int)Math.floor(lastRecorded*10))
         System.out.printf(Locale.ROOT,"GRAVITY t=%.4f code, fraction=%.3f, maximum displacement=%.6f mm%n",time,appliedScale,Math.max(Math.max(peak[0],peak[1]),Math.max(peak[2],peak[3])));
      lastRecorded=time;
      return Math.max(Math.max(peak[0],peak[1]),Math.max(peak[2],peak[3]));
   }

   private void snapshot(double time) throws IOException {
      if(Math.abs(time-lastSnapshot)<1e-9) return;
      for(SurfaceLoadMap.NodeLoad nl:map.nodes) {
         Point3d p=nl.node.getPosition(); Vector3d v=nl.node.getVelocity();
         snapshots.printf(Locale.ROOT,"%.12g,%d,%d,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g%n",
            time,nl.fold,nl.node.getNumber(),p.x,p.y,p.z,p.x-nl.initial.x,p.y-nl.initial.y,p.z-nl.initial.z,
            appliedScale*nl.force.x,appliedScale*nl.force.y,appliedScale*nl.force.z,v.x,v.y,v.z);
      }
      lastSnapshot=time;
      snapshots.flush(); if(snapshots.checkError()) throw new IOException("Cannot write FEM snapshot");
   }

   private void writeInitialLoads() throws IOException {
      try(PrintWriter w=writer("initial_nodal_loads.csv")) {
         w.println("fold,node,dynamic,x_mm,y_mm,z_mm,area_weight_mm2,area_weighted_pressure_Pa,full_fx_microN,full_fy_microN,full_fz_microN");
         for(SurfaceLoadMap.NodeLoad n:map.nodes) w.printf(Locale.ROOT,"%d,%d,%s,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g%n",
            n.fold,n.node.getNumber(),n.node.isDynamic(),n.initial.x,n.initial.y,n.initial.z,n.area,n.area>0?n.pressureArea/n.area:0,n.force.x,n.force.y,n.force.z);
         if(w.checkError()) throw new IOException("Cannot write initial nodal loads");
      }
   }

   private void writeMetadata(Path source,PressureSnapshot p,double maxStep) throws IOException {
      String hash;
      try {
         byte[] digest=MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(source));
         StringBuilder b=new StringBuilder(); for(byte v:digest) b.append(String.format(Locale.ROOT,"%02x",v&255)); hash=b.toString();
      } catch(java.security.NoSuchAlgorithmException e) { throw new IOException(e); }
      try(PrintWriter w=writer("metadata.txt")) {
         w.println("kind=gravity/contact check with frozen LBM pressure-pattern loads; not continuous FSI");
         w.println("source_pressure_zip="+source.toAbsolutePath()); w.println("source_sha256="+hash);
         w.println("source_lattice_step=6000; developing flow snapshot, not certified steady");
         w.println("pressure_pattern=target_Pa * (p_lattice - outlet_mean)/(inlet_mean - outlet_mean), separately per slice");
         w.println("target_pressure_difference_Pa="+targetPa);
         w.println("pressure_scaling=chosen loading normalisation, not calibration of LBM air properties, velocities or time");
         w.println("declared_units_for_this_test=length mm; stress Pa; nodal force microN; code time 0.01 s");
         w.println("unit_convention_is_adopted_for_this_test_not_proven_historical_intent=true");
         w.println("density_conversion=1 code density = 100 kg/m3; vocal density 10 = 1000 kg/m3; vent density 8 = 800 kg/m3");
         w.println("force_rule=F_node_microN = -sum(pressure_Pa * initial_patch_area_mm2 * mean_shape_weight * initial_outward_normal)");
         w.println("reference_configuration_loads=true; normals, areas and sampled pressures are held at their initial values");
         w.println("pressure_sampling=fluid-only bilinear interpolation; outward probes at 0.75, 1.25, 1.75 grid cells; first available used");
         w.println("surfaces=existing triangles clipped to x within +/-7.8 mm and three AP bands; AP endcaps and outer attachments excluded");
         w.println("external_tissue_pressure_reference=0 Pa gauge; no prestress added");
         w.println("old_forcing_controller=not instantiated; external nodal loads set explicitly each interval");
         w.println("gravity_vector_code=0,"+gravityY+",0");
         w.println("original_model_gravity_vector_code=0,-9.8,0; verified from supplied VocalVentricularModel.java");
         w.println("gravity_applies_to_all_four_FEMs=true");
         w.println("gravity_physical_interpretation_under_adopted_units_m_s2="+(10*gravityY));
         w.println("standard_gravity_under_adopted_units_code=approximately -0.981 along y");
         w.println("gravity_parameter_matches_original_code="+(Math.abs(gravityY+9.8)<1e-12));
         w.println("gravity_is_a_declared_code_parameter_not_an_automatically_calibrated_Earth_value=true");
         w.println("recorder_version=2");
         w.println("contact_observation=CollisionHandler.getLastContactInfo geometry evidence plus getContactForces(0), recorded after accepted intervals");
         w.println("legacy_inContact_bypassed=true; supplied core returns true for an empty handler list");
         w.println("initial_clearance=verified positive vocal x bounds and ipsilateral vocal-ventricular y bounds before stepping");
         w.println("contact_force_threshold_microN="+ContactRecorder.MIN_CONTACT_FORCE_MICRONEWTON);
         w.println("contact_timing=first sampled detection; response may lag current geometry by an integration step");
         w.println("vertical_separation=min ventricular y minus max vocal y; bounding-coordinate measure, not exact nearest-surface distance");
         w.println("contact_does_not_establish_damping_or_self_sustained_oscillation=true");
         w.println("contact_overlay=green arrows, front-projected and scaled to 1.4 mm maximum; pressure arrows remain cyan");
         w.println("boundary_normals_areas_and_pressure_not_updated_during_gravity_motion=true");
         w.println("comparison_to_previous_no_gravity_recording=shared 0 to 2 code interval only; remaining tail has no previously recorded matched control");
         w.println("gravity_active_from_t0=true; initial gravity equilibrium is not pre-solved");
         w.println("abort_on_inverted_elements=true");
         w.println("materials=unchanged baseline mesh-builder material and density values");
         w.println("fixation=original lateral attachment planes; AP ends free");
         w.println("collision_pairs=left-right vocal (friction 0.5), ipsilateral vocal-ventricular (friction 0)");
         w.println("ramp=half cosine; ramp_duration_code="+ramp); w.println("end_time_code="+end);
         w.println("max_step_code="+maxStep); w.println("maximum_displacement_guard_mm="+maxDisplacement);
         w.println("reference_x_separation=tracked node proxy; not exact glottal area or minimum opening");
         w.println("visual_arrows=cyan, selected middle-band nodes; XY forces projected to front display plane z=7.2 mm with magnified length; actual applied forces remain 3D and physical deformation is not magnified");
         w.println("fold_indices=0 vocal_left, 1 vocal_right, 2 ventricular_left, 3 ventricular_right");
         w.println("provenance=Yong FEM builders; current pressure source uses the separate instrumented D2Q9 diagnostic, not the original Kummerlaender shader/Moisik wrapper");
         for(int s=0;s<3;s++) w.println("slice_"+(s+1)+"_source_inlet_outlet_pressure_lattice="+p.inlet[s]+","+p.outlet[s]);
         for(int f=0;f<4;f++) w.println(NAMES[f]+"_nodes="+folds[f].numNodes());
      }
   }

   private PrintWriter writer(String name) throws IOException {
      return new PrintWriter(Files.newBufferedWriter(output.resolve(name),StandardCharsets.UTF_8));
   }
   private void fail(Exception e,double time) {
      finished=true; setStopRequest(true);
      try { snapshot(time); } catch(IOException ignored) { }
      if(contact!=null) { try { contact.finish(); } catch(IOException ignored) { } contact.close(); }
      if(summary!=null) summary.close(); if(snapshots!=null) snapshots.close();
      try { Files.write(output.resolve("GRAVITY_CONTACT_FAILED.txt"),e.toString().getBytes(StandardCharsets.UTF_8)); } catch(IOException ignored) { }
      System.err.println("GRAVITY CONTACT CHECK STOPPED: "+e); System.err.println("Output: "+output); e.printStackTrace();
   }
   @Override public void detach(DriverInterface driver) {
      if(summary!=null) summary.close(); if(snapshots!=null) snapshots.close();
      if(contact!=null) contact.close();
      super.detach(driver);
   }

   private final class LoadArrows extends RenderableComponentBase {
      final ArrayList<SurfaceLoadMap.NodeLoad> selected=new ArrayList<SurfaceLoadMap.NodeLoad>();
      final double gain;
      LoadArrows() {
         ArrayList<SurfaceLoadMap.NodeLoad> possible=new ArrayList<SurfaceLoadMap.NodeLoad>();
         double max=0;
         for(SurfaceLoadMap.NodeLoad n:map.nodes) {
            max=Math.max(max,n.force.norm());
            if(n.node.isDynamic() && Math.abs(n.initial.z)<1 && n.force.norm()>1e-8) possible.add(n);
         }
         int stride=Math.max(1,(possible.size()+39)/40);
         for(int i=0;i<possible.size();i+=stride) selected.add(possible.get(i));
         gain=max>0?1.8/max:0;
      }
      @Override public void render(Renderer renderer,int flags) {
         if(appliedScale<=0) return;
         renderer.setColor(0.15f,0.9f,1f);
         for(SurfaceLoadMap.NodeLoad n:selected) {
            Point3d p=n.node.getPosition();
            Point3d a=new Point3d(p.x,p.y,7.2);
            Point3d b=new Point3d(p.x+gain*appliedScale*n.force.x,
                                  p.y+gain*appliedScale*n.force.y,7.2);
            renderer.drawArrow(a,b,0.025,true);
         }
      }
      @Override public void updateBounds(Vector3d min,Vector3d max) {
         for(SurfaceLoadMap.NodeLoad n:selected) {
            Point3d p=n.node.getPosition();
            new Point3d(p.x,p.y,7.2).updateBounds(min,max);
            new Point3d(p.x+gain*n.force.x,p.y+gain*n.force.y,7.2).updateBounds(min,max);
         }
      }
   }
}
