package artisynth.models.vocVent.transientfsi;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.Locale;

import artisynth.core.femmodels.FemModel3d;
import artisynth.core.femmodels.FemNode3d;
import maspack.geometry.Face;
import maspack.geometry.Vertex3d;
import maspack.matrix.Point3d;
import maspack.matrix.Vector3d;

/** Current-surface pressure quadrature and conservative nodal distribution; fixed reference positions for measurements. */
final class SurfaceLoadMap {
   static final class NodeLoad {
      final FemNode3d node;
      final int fold;
      final Point3d initial;
      final Vector3d force=new Vector3d(); // Pa * mm^2 = microN in the declared model.
      double area, pressureArea;
      NodeLoad(FemNode3d node,int fold) { this.node=node; this.fold=fold; initial=new Point3d(node.getPosition()); }
   }
   final ArrayList<NodeLoad> nodes=new ArrayList<NodeLoad>();
   final IdentityHashMap<FemNode3d,NodeLoad> byNode=new IdentityHashMap<FemNode3d,NodeLoad>();
   final double[][] candidateArea=new double[4][3], sampledArea=new double[4][3];
   final Vector3d[] integratedForce={new Vector3d(),new Vector3d(),new Vector3d(),new Vector3d()};
   private static final double EPS=1e-8;

   private final FemModel3d[] folds;
   boolean referenceGeometry;
   private final java.util.HashSet<String> excluded=new java.util.HashSet<String>();
   SurfaceLoadMap(FemModel3d[] folds,FluidFields pressure,PrintWriter quadrature,
                  PrintWriter triangles,PrintWriter checks) throws IOException {
      this.folds=folds;
      for(int f=0;f<4;f++) for(FemNode3d n:folds[f].getNodes()) {
         NodeLoad nl=new NodeLoad(n,f); nodes.add(nl); byNode.put(n,nl);
      }
      update(pressure,quadrature,triangles,checks,true);
   }
   void update(FluidFields pressure,PrintWriter quadrature,PrintWriter triangles,PrintWriter checks,boolean initial) throws IOException {
      if(quadrature!=null)quadrature.println("fold,source_triangle,slice,area_mm2,cx_mm,cy_mm,cz_mm,pressure_Pa,nx,ny,nz,node0,node1,node2,N0,N1,N2");
      if(triangles!=null)triangles.println("fold,triangle,node0,node1,node2");
      if(checks!=null)checks.println("fold,slice,candidate_area_mm2,sampled_area_mm2,unsampled_area_mm2");
      for(NodeLoad n:nodes){n.force.setZero();n.area=0;n.pressureArea=0;}
      for(int f=0;f<4;f++){java.util.Arrays.fill(candidateArea[f],0);java.util.Arrays.fill(sampledArea[f],0);integratedForce[f].setZero();}
      for(int f=0;f<4;f++) {
         int faceIndex=0; double signedVolume=0;
         for(Face face:folds[f].getSurfaceMesh().getFaces()) {
            Vertex3d[] vs=face.getVertices();
            if(vs.length!=3) throw new IOException("Expected triangular FEM surface");
            FemNode3d[] ns={folds[f].getSurfaceNode(vs[0]),folds[f].getSurfaceNode(vs[1]),folds[f].getSurfaceNode(vs[2])};
            double[][] v=new double[3][6];
            for(int k=0;k<3;k++) {
               if(ns[k]==null || (initial && vs[k].getWorldPoint().distance(ns[k].getPosition())>1e-6))
                  throw new IOException("Surface/FEM node binding mismatch");
               Point3d p=referenceGeometry?byNode.get(ns[k]).initial:ns[k].getPosition(); v[k][0]=p.x; v[k][1]=p.y; v[k][2]=p.z; v[k][3+k]=1;
            }
            faceIndex++;
            if(triangles!=null)triangles.printf(Locale.ROOT,"%d,%d,%d,%d,%d%n",f,faceIndex,ns[0].getNumber(),ns[1].getNumber(),ns[2].getNumber());
            signedVolume+=(v[0][0]*(v[1][1]*v[2][2]-v[1][2]*v[2][1])+v[0][1]*(v[1][2]*v[2][0]-v[1][0]*v[2][2])+v[0][2]*(v[1][0]*v[2][1]-v[1][1]*v[2][0]))/6.0;
            String key=f+":"+faceIndex;
            if(initial && (onPlane(v,2,-7)||onPlane(v,2,7)||onPlane(v,0,-7.8)||onPlane(v,0,7.8)))excluded.add(key);
            if(excluded.contains(key))continue;
            Vector3d normal=cross(v[0],v[1],v[2]); double twice=normal.norm();
            if(!(twice>1e-12)) throw new IOException("Degenerate surface triangle");
            normal.scale(1.0/twice);
            if(Math.hypot(normal.x,normal.y)<1e-10) continue;
            ArrayList<double[]> poly=new ArrayList<double[]>(); for(double[] row:v) poly.add(row);
            poly=clip(clip(poly,0,-7.8,true),0,7.8,false);
            for(int s=0;s<3;s++) {
               double lower=-7+s*14.0/3.0,upper=-7+(s+1)*14.0/3.0;
               ArrayList<double[]> band=clip(clip(poly,2,lower,true),2,upper,false);
               for(int k=1;k+1<band.size();k++) {
                  double[][] q={band.get(0),band.get(k),band.get(k+1)};
                  double area=cross(q[0],q[1],q[2]).norm()*0.5;
                  if(area<1e-12) continue;
                  candidateArea[f][s]+=area;
                  double[] centre=new double[6];
                  for(double[] row:q) for(int j=0;j<6;j++) centre[j]+=row[j]/3.0;
                  double p=Double.NaN, nxy=Math.hypot(normal.x,normal.y);
                  for(double cells:new double[]{0.75,1.25,1.75}) {
                     p=pressure.samplePa(s,centre[0]+cells*FluidFields.DX*normal.x/nxy,
                                           centre[1]+cells*FluidFields.DX*normal.y/nxy);
                     if(Double.isFinite(p)) break;
                  }
                  if(!Double.isFinite(p)) continue;
                  sampledArea[f][s]+=area;
                  integratedForce[f].scaledAdd(-p*area,normal);
                  double sum=centre[3]+centre[4]+centre[5];
                  if(Math.abs(sum-1)>1e-10) throw new IOException("Invalid shape weights");
                  for(int j=0;j<3;j++) {
                     if(centre[3+j]<-1e-10) throw new IOException("Negative shape weight");
                     NodeLoad nl=byNode.get(ns[j]); double a=area*centre[3+j];
                     nl.area+=a; nl.pressureArea+=p*a; nl.force.scaledAdd(-p*a,normal);
                  }
                  if(quadrature!=null)quadrature.printf(Locale.ROOT,"%d,%d,%d,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%d,%d,%d,%.12g,%.12g,%.12g%n",
                     f,faceIndex,s+1,area,centre[0],centre[1],centre[2],p,normal.x,normal.y,normal.z,
                     ns[0].getNumber(),ns[1].getNumber(),ns[2].getNumber(),centre[3],centre[4],centre[5]);
               }
            }
         }
         if(!(signedVolume>0)) throw new IOException("Expected outward surface winding for fold "+f);
         double area=0,sampled=0,nodeArea=0; Vector3d sum=new Vector3d(); int loaded=0;
         for(int s=0;s<3;s++) {
            area+=candidateArea[f][s]; sampled+=sampledArea[f][s];
            if(checks!=null)checks.printf(Locale.ROOT,"%d,%d,%.12g,%.12g,%.12g%n",f,s+1,candidateArea[f][s],sampledArea[f][s],candidateArea[f][s]-sampledArea[f][s]);
         }
         for(NodeLoad nl:nodes) if(nl.fold==f) { sum.add(nl.force); nodeArea+=nl.area; if(nl.area>0) loaded++; }
         Vector3d error=new Vector3d(); error.sub(sum,integratedForce[f]);
         if(area<=0 || (initial && sampled/area<0.995))throw new IOException("Invalid initial pressure sampling on fold "+f);
         // During contact, buried faces have no adjacent fluid and receive no pressure.
         if(!Double.isFinite(sum.norm()))throw new IOException("Non-finite pressure transfer");
         if(Math.abs(sampled-nodeArea)>1e-7 || error.norm()>1e-8*Math.max(1,integratedForce[f].norm()))
            throw new IOException("Nodal pressure-transfer conservation check failed");
         if(initial)System.out.printf(Locale.ROOT,"FSI MAP fold=%d: sampled %.6f / %.6f mm2; %d loaded nodes; resultant [%.6f, %.6f, %.6f] microN%n",
            f,sampled,area,loaded,sum.x,sum.y,sum.z);
      }
      if((quadrature!=null&&quadrature.checkError())||(triangles!=null&&triangles.checkError())||(checks!=null&&checks.checkError()))throw new IOException("Could not write pressure map");
   }

   private static boolean onPlane(double[][] t,int axis,double v) {
      for(double[] p:t) if(Math.abs(p[axis]-v)>EPS) return false;
      return true;
   }
   private static Vector3d cross(double[] a,double[] b,double[] c) {
      Vector3d ab=new Vector3d(b[0]-a[0],b[1]-a[1],b[2]-a[2]);
      Vector3d ac=new Vector3d(c[0]-a[0],c[1]-a[1],c[2]-a[2]);
      Vector3d n=new Vector3d(); n.cross(ab,ac); return n;
   }
   private static ArrayList<double[]> clip(ArrayList<double[]> in,int axis,double bound,boolean greater) {
      ArrayList<double[]> out=new ArrayList<double[]>(); if(in.isEmpty()) return out;
      double[] prev=in.get(in.size()-1); double dp=(prev[axis]-bound)*(greater?1:-1);
      for(double[] current:in) {
         double dc=(current[axis]-bound)*(greater?1:-1);
         boolean pin=dp>=-EPS,cin=dc>=-EPS;
         if(pin!=cin) {
            double t=Math.max(0,Math.min(1,dp/(dp-dc))); double[] p=new double[6];
            for(int j=0;j<6;j++) p[j]=prev[j]+t*(current[j]-prev[j]); out.add(p);
         }
         if(cin) out.add(current);
         prev=current; dp=dc;
      }
      return out;
   }
}
