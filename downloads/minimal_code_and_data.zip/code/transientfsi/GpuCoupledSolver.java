package artisynth.models.vocVent.transientfsi;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.nio.charset.StandardCharsets;

import com.jogamp.opengl.GL;
import com.jogamp.opengl.GL4;
import com.jogamp.opengl.GLAutoDrawable;
import com.jogamp.opengl.GLCapabilities;
import com.jogamp.opengl.GLDrawableFactory;
import com.jogamp.opengl.GLEventListener;
import com.jogamp.opengl.GLOffscreenAutoDrawable;
import com.jogamp.opengl.GLProfile;
import com.jogamp.opengl.GLRunnable;
import com.jogamp.opengl.util.GLBuffers;

/** Persistent offscreen GPU fluid state, geometry remapping and moving-wall bounce-back. */
final class GpuCoupledSolver implements GLEventListener, AutoCloseable {
   private final int nx, ny;
   private final int[][] materials;
   private final float tau, deltaRho;
   private final int rampSteps;
   private final GLOffscreenAutoDrawable drawable;
   private int program,repairProgram;
   private final IntBuffer[] matTransfer;
   private final FloatBuffer[] wallTransfer,macroTransfer;
   private int[][] bufferIds;
   private boolean[] aIsCurrent;
   private boolean ready, closed;
   private RuntimeException initFailure;

   GpuCoupledSolver(int nx, int ny, int[][] materials, float tau,
                     float deltaRho, int rampSteps) {
      this.nx = nx; this.ny = ny; this.materials = materials;
      matTransfer=new IntBuffer[materials.length];wallTransfer=new FloatBuffer[materials.length];macroTransfer=new FloatBuffer[materials.length];
      for(int s=0;s<materials.length;s++){matTransfer[s]=GLBuffers.newDirectIntBuffer(nx*ny);wallTransfer[s]=GLBuffers.newDirectFloatBuffer(nx*ny*4);macroTransfer[s]=GLBuffers.newDirectFloatBuffer(nx*ny*4);}
      this.tau = tau; this.deltaRho = deltaRho; this.rampSteps = rampSteps;
      GLProfile profile = GLProfile.get(GLProfile.GL4);
      GLCapabilities caps = new GLCapabilities(profile);
      drawable = GLDrawableFactory.getFactory(profile)
         .createOffscreenAutoDrawable(null, caps, null, 16, 16);
      drawable.addGLEventListener(this);
      drawable.display(); // Initialise buffers and compile; do not advance fluid.
      if (initFailure != null) {
         drawable.destroy();
         throw initFailure;
      }
      if (!ready) throw new IllegalStateException("GPU context did not initialise");
   }

   @Override public void init(GLAutoDrawable d) {
      try {
         GL4 gl = d.getGL().getGL4();
         program = makeProgram(gl, resource("d2q9_coupled.comp"));
         repairProgram=makeProgram(gl,resource("repair_cells.comp"));
         bufferIds = new int[materials.length][6];
         aIsCurrent = new boolean[materials.length];
         float[] weights = {4f/9f,1f/9f,1f/9f,1f/9f,1f/9f,
                            1f/36f,1f/36f,1f/36f,1f/36f};
         float[] initial = new float[nx*ny*9];
         for (int c=0; c<nx*ny; c++)
            System.arraycopy(weights,0,initial,c*9,9);
         for (int s=0; s<materials.length; s++) {
            gl.glGenBuffers(6, bufferIds[s], 0);
            allocate(gl, bufferIds[s][0], initial);
            allocate(gl, bufferIds[s][1], initial);
            IntBuffer mat = GLBuffers.newDirectIntBuffer(materials[s]);
            gl.glBindBuffer(GL4.GL_SHADER_STORAGE_BUFFER, bufferIds[s][2]);
            gl.glBufferData(GL4.GL_SHADER_STORAGE_BUFFER,
               (long)materials[s].length*4, mat, GL4.GL_STATIC_DRAW);
            gl.glBindBuffer(GL4.GL_SHADER_STORAGE_BUFFER, bufferIds[s][3]);
            gl.glBufferData(GL4.GL_SHADER_STORAGE_BUFFER,
               (long)nx*ny*4*4, null, GL4.GL_DYNAMIC_READ);
            gl.glBindBuffer(GL4.GL_SHADER_STORAGE_BUFFER,bufferIds[s][4]);
            gl.glBufferData(GL4.GL_SHADER_STORAGE_BUFFER,(long)nx*ny*16,null,GL4.GL_DYNAMIC_DRAW);
            mat.rewind();gl.glBindBuffer(GL4.GL_SHADER_STORAGE_BUFFER,bufferIds[s][5]);
            gl.glBufferData(GL4.GL_SHADER_STORAGE_BUFFER,(long)nx*ny*4,mat,GL4.GL_DYNAMIC_DRAW);
            aIsCurrent[s] = true;
         }
         System.out.println("FSI GPU: " + gl.glGetString(GL.GL_RENDERER));
         ready = true;
      } catch (IOException | RuntimeException e) {
         initFailure = new IllegalStateException("Coupled GPU initialisation failed",e);
      }
   }

   /** Run exactly count fluid steps per slice, independent of repaint timing. */
   float[][] advance(final int firstCompletedStep, final int count, final MovingSlices.Slice[] slices) {
      if (!ready || closed) throw new IllegalStateException("Coupled GPU is not ready");
      final float[][] result = new float[materials.length][];
      final RuntimeException[] failure = new RuntimeException[1];
      boolean invoked = drawable.invoke(true, new GLRunnable() {
         @Override public boolean run(GLAutoDrawable d) {
            try {
               GL4 gl = d.getGL().getGL4();

               for (int s=0; s<materials.length; s++) {
                  IntBuffer mb=matTransfer[s];mb.clear();mb.put(slices[s].material);mb.flip();
                  FloatBuffer wb=wallTransfer[s];wb.clear();wb.put(slices[s].wall);wb.flip();
                  gl.glBindBuffer(GL4.GL_SHADER_STORAGE_BUFFER,bufferIds[s][2]);
                  gl.glBufferSubData(GL4.GL_SHADER_STORAGE_BUFFER,0,(long)nx*ny*4,mb);
                  gl.glBindBuffer(GL4.GL_SHADER_STORAGE_BUFFER,bufferIds[s][4]);
                  gl.glBufferSubData(GL4.GL_SHADER_STORAGE_BUFFER,0,(long)nx*ny*16,wb);
                  for(int b=2;b<6;b++)gl.glBindBufferBase(GL4.GL_SHADER_STORAGE_BUFFER,b,bufferIds[s][b]);
                  gl.glUseProgram(repairProgram);
                  gl.glUniform1i(gl.glGetUniformLocation(repairProgram,"nx"),nx);
                  gl.glUniform1i(gl.glGetUniformLocation(repairProgram,"ny"),ny);
                  gl.glBindBufferBase(GL4.GL_SHADER_STORAGE_BUFFER,0,bufferIds[s][aIsCurrent[s]?0:1]);
                  gl.glBindBufferBase(GL4.GL_SHADER_STORAGE_BUFFER,1,bufferIds[s][aIsCurrent[s]?1:0]);
                  gl.glDispatchCompute((nx+15)/16,(ny+15)/16,1);
                  gl.glMemoryBarrier(GL4.GL_SHADER_STORAGE_BARRIER_BIT|GL4.GL_BUFFER_UPDATE_BARRIER_BIT);
                  aIsCurrent[s]=!aIsCurrent[s];
                  mb.rewind();gl.glBindBuffer(GL4.GL_SHADER_STORAGE_BUFFER,bufferIds[s][5]);
                  gl.glBufferSubData(GL4.GL_SHADER_STORAGE_BUFFER,0,(long)nx*ny*4,mb);
                  gl.glMemoryBarrier(GL4.GL_SHADER_STORAGE_BARRIER_BIT|GL4.GL_BUFFER_UPDATE_BARRIER_BIT);
                  gl.glUseProgram(program);
                  gl.glUniform1i(gl.glGetUniformLocation(program,"nx"),nx);
                  gl.glUniform1i(gl.glGetUniformLocation(program,"ny"),ny);
                  gl.glUniform1f(gl.glGetUniformLocation(program,"tau"),tau);
                  int rhoLoc=gl.glGetUniformLocation(program,"rhoIn");
                  gl.glBindBufferBase(GL4.GL_SHADER_STORAGE_BUFFER,2,bufferIds[s][2]);
                  gl.glBindBufferBase(GL4.GL_SHADER_STORAGE_BUFFER,3,bufferIds[s][3]);
                  for (int k=1; k<=count; k++) {
                     float phase=Math.min(1f,(firstCompletedStep+k)/(float)rampSteps);
                     float ramp=.5f*(1f-(float)Math.cos(Math.PI*phase));
                     gl.glUniform1f(rhoLoc,1f+deltaRho*ramp);
                     gl.glBindBufferBase(GL4.GL_SHADER_STORAGE_BUFFER,0,
                        bufferIds[s][aIsCurrent[s]?0:1]);
                     gl.glBindBufferBase(GL4.GL_SHADER_STORAGE_BUFFER,1,
                        bufferIds[s][aIsCurrent[s]?1:0]);
                     gl.glDispatchCompute((nx+15)/16,(ny+15)/16,1);
                     gl.glMemoryBarrier(GL4.GL_SHADER_STORAGE_BARRIER_BIT);
                     aIsCurrent[s] = !aIsCurrent[s];
                  }
                  gl.glMemoryBarrier(GL4.GL_BUFFER_UPDATE_BARRIER_BIT);
                  FloatBuffer macro=macroTransfer[s];macro.clear();
                  gl.glBindBuffer(GL4.GL_SHADER_STORAGE_BUFFER,bufferIds[s][3]);
                  gl.glGetBufferSubData(GL4.GL_SHADER_STORAGE_BUFFER,0,
                     (long)nx*ny*4*4,macro);
                  result[s] = new float[nx*ny*4];
                  macro.rewind(); macro.get(result[s]);
               }
               int error = gl.glGetError();
               if (error != GL.GL_NO_ERROR)
                  throw new IllegalStateException("OpenGL error " + error);
               gl.glUseProgram(0);
            } catch (RuntimeException e) { failure[0] = e; }
            return false; // No offscreen image needs repainting.
         }
      });
      if (!invoked) throw new IllegalStateException("GPU work was not executed");
      if (failure[0] != null) throw failure[0];
      return result;
   }

   private static void allocate(GL4 gl,int id,float[] data) {
      gl.glBindBuffer(GL4.GL_SHADER_STORAGE_BUFFER,id);
      gl.glBufferData(GL4.GL_SHADER_STORAGE_BUFFER,(long)data.length*4,
         GLBuffers.newDirectFloatBuffer(data),GL4.GL_DYNAMIC_COPY);
   }

   private static String resource(String name) throws IOException {
      try (InputStream in=GpuCoupledSolver.class.getResourceAsStream(name)) {
         if (in==null) throw new IOException("Missing shader resource: "+name);
         ByteArrayOutputStream out = new ByteArrayOutputStream();
         byte[] block = new byte[8192]; int n;
         while ((n=in.read(block))!=-1) out.write(block,0,n);
         return new String(out.toByteArray(),StandardCharsets.UTF_8);
      }
   }

   private static int makeProgram(GL4 gl,String source) {
      int shader=gl.glCreateShader(GL4.GL_COMPUTE_SHADER);
      gl.glShaderSource(shader,1,new String[]{source},null,0);
      gl.glCompileShader(shader);
      int[] status=new int[1];
      gl.glGetShaderiv(shader,GL4.GL_COMPILE_STATUS,status,0);
      if(status[0]==0) {
         int[] len=new int[1]; gl.glGetShaderiv(shader,GL4.GL_INFO_LOG_LENGTH,len,0);
         byte[] log=new byte[Math.max(1,len[0])];
         gl.glGetShaderInfoLog(shader,log.length,null,0,log,0);
         throw new IllegalStateException("Compute shader: "+new String(log,StandardCharsets.UTF_8));
      }
      int p=gl.glCreateProgram(); gl.glAttachShader(p,shader); gl.glLinkProgram(p);
      gl.glGetProgramiv(p,GL4.GL_LINK_STATUS,status,0);
      if(status[0]==0) {
         int[] len=new int[1]; gl.glGetProgramiv(p,GL4.GL_INFO_LOG_LENGTH,len,0);
         byte[] log=new byte[Math.max(1,len[0])];
         gl.glGetProgramInfoLog(p,log.length,null,0,log,0);
         throw new IllegalStateException("Compute linking: "+new String(log,StandardCharsets.UTF_8));
      }
      gl.glDetachShader(p,shader); gl.glDeleteShader(shader);
      return p;
   }

   @Override public void display(GLAutoDrawable d) { }
   @Override public void reshape(GLAutoDrawable d,int x,int y,int w,int h) { }
   @Override public void dispose(GLAutoDrawable d) {
      GL4 gl=d.getGL().getGL4();
      if(bufferIds!=null) for(int[] ids:bufferIds) gl.glDeleteBuffers(6,ids,0);
      if(program!=0) gl.glDeleteProgram(program);
      if(repairProgram!=0)gl.glDeleteProgram(repairProgram);
      ready=false;
   }
   @Override public void close() {
      if (!closed) { closed=true; drawable.destroy(); }
   }
}
