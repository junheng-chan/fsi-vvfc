package artisynth.models.vocVent.transientfsi;

/** Shared dimensional convention, fixed grid and live pressure interpolation. */
final class FluidFields {
   static final int NX=314, NY=402;
   static final double DX=.05, X0=-7.825, Y0=-10.025;
   // Time refinement preserves density, effective viscosity and target pressure.
   static final double CODE_SECOND=.01, DT=2.5e-7, DENSITY=1.2, TAU=.55;
   static final double VELOCITY=(DX*.001)/DT;
   static final double PRESSURE=DENSITY*VELOCITY*VELOCITY;
   static final double VISCOSITY=(TAU-.5)/3*(DX*.001)*(DX*.001)/DT;
   static final double WALL_VELOCITY=.001/CODE_SECOND/VELOCITY;
   static final double[] Z={-14./3,0,14./3};
   final int[][] material=new int[3][];
   float[][] macro;
   static boolean fluid(int m) { return m==1 || m==5 || m==6; }
   static double x(int i) { return X0+i*DX; }
   static double y(int j) { return Y0+j*DX; }
   void set(MovingSlices.Slice[] slices,float[][] values) {
      macro=values; for(int s=0;s<3;s++) material[s]=slices[s].material;
   }
   double samplePa(int s,double x,double y) {
      double gx=(x-X0)/DX, gy=(y-Y0)/DX;
      int i=(int)Math.floor(gx),j=(int)Math.floor(gy);
      double tx=gx-i,ty=gy-j,sum=0,weight=0;
      for(int dj=0;dj<2;dj++) for(int di=0;di<2;di++) {
         int ii=i+di,jj=j+dj;
         if(ii<0||ii>=NX||jj<0||jj>=NY) continue;
         int a=jj*NX+ii; double w=(di==0?1-tx:tx)*(dj==0?1-ty:ty);
         if(fluid(material[s][a]) && w>0) {
            double rho=macro==null?1:macro[s][4*a];
            sum+=w*(rho-1)*PRESSURE/3; weight+=w;
         }
      }
      return weight>1e-12?sum/weight:Double.NaN;
   }
}
