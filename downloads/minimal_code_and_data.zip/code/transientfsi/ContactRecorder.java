package artisynth.models.vocVent.transientfsi;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import artisynth.core.femmodels.FemModel3d;
import artisynth.core.mechmodels.CollisionResponse;
import artisynth.core.mechmodels.CollisionHandler;
import artisynth.core.mechmodels.MechModel;
import artisynth.core.modelbase.RenderableComponentBase;
import maspack.geometry.Vertex3d;
import maspack.collision.ContactInfo;
import maspack.matrix.Point3d;
import maspack.matrix.Vector3d;
import maspack.render.Renderer;

/** Read collision responses and tissue descent after accepted FEM intervals. */
final class ContactRecorder implements AutoCloseable {
   static final double MIN_CONTACT_FORCE_MICRONEWTON=1e-6;
   private static final String[] PAIRS={"vocal_left_right","vocal_ventricular_left","vocal_ventricular_right"};
   private final CollisionResponse[] response=new CollisionResponse[3];
   private final SurfaceLoadMap loads;
   private final PrintWriter contacts,verticesLog,descent,separation,events;
   private final Path output;
   private final double[] firstIntersection={-1,-1,-1},firstForce={-1,-1,-1},maxVertexForce=new double[3];
   private final int[] intersectionSamples=new int[3],forceSamples=new int[3];
   private int records;
   private static final class Arrow {
      final Point3d point; final Vector3d force;
      Arrow(Point3d p,Vector3d f) { point=new Point3d(p); force=new Vector3d(f); }
   }
   private volatile List<Arrow> arrows=Collections.emptyList();

   ContactRecorder(MechModel mech,FemModel3d[] folds,SurfaceLoadMap loads,Path output) throws IOException {
      this.loads=loads; this.output=output;
      response[0]=mech.setCollisionResponse(folds[0],folds[1]);
      response[1]=mech.setCollisionResponse(folds[0],folds[2]);
      response[2]=mech.setCollisionResponse(folds[1],folds[3]);
      contacts=writer("contacts.csv"); descent=writer("descent.csv");
      verticesLog=writer("contact_vertices.csv");
      separation=writer("vertical_separation.csv"); events=writer("contact_events.csv");
      contacts.println("t_code,pair,in_contact,load_bearing,force_vertices_on_body0,resultant_fx_microN,resultant_fy_microN,resultant_fz_microN,resultant_norm_microN,sum_vertex_force_magnitudes_microN,max_vertex_force_microN,collision_handlers,handlers_with_geometry_data");
      verticesLog.println("t_code,pair,body_index,collision_vertex_index,x_mm,y_mm,z_mm,fx_microN,fy_microN,fz_microN");
      descent.println("t_code,fold,dynamic_nodes,mean_dynamic_dy_mm,min_dynamic_dy_mm,max_dynamic_dy_mm,min_y_mm,max_y_mm,maximum_displacement_mm");
      separation.println("t_code,pair,vent_min_y_minus_vocal_max_y_mm");
      events.println("t_code,pair,event");
   }

   static final class GeometryEvidence {
      boolean contact;
      int handlers,withData;
   }

   // The supplied legacy CollisionResponse.inContact() returns true for an
   // EMPTY handler list. Avoid it entirely; inspect computed geometry records.
   static GeometryEvidence geometryEvidence(CollisionResponse response) {
      GeometryEvidence evidence=new GeometryEvidence();
      for(CollisionHandler handler:response.getHandlers()) {
         evidence.handlers++;
         ContactInfo info=handler.getLastContactInfo();
         if(info==null) continue;
         evidence.withData++;
         if(infoShowsContact(info)) evidence.contact=true;
      }
      return evidence;
   }

   static boolean infoShowsContact(ContactInfo info) {
      if(info==null) return false;
      if(info.numContours()>0) return true;
      if(info.getIntersections()!=null && !info.getIntersections().isEmpty()) return true;
      // Also catches containment, where surface-intersection contours may be
      // absent although mesh vertices penetrate the other body.
      return !info.getPenetratingPoints(0).isEmpty() || !info.getPenetratingPoints(1).isEmpty();
   }

   /** Returns true only at the first sampled load-bearing VV contact. */
   boolean record(double time) throws IOException {
      records++;
      ArrayList<Arrow> display=new ArrayList<Arrow>(); boolean firstVVForce=false;
      for(int pair=0;pair<3;pair++) {
         GeometryEvidence evidence=geometryEvidence(response[pair]);
         boolean intersects=evidence.contact;
         Map<Vertex3d,Vector3d> map=response[pair].getContactForces(0);
         Vector3d sum=new Vector3d(); double total=0,largest=0; int vertices=0;
         if(map!=null) for(Map.Entry<Vertex3d,Vector3d> entry:map.entrySet()) {
            Vector3d f=entry.getValue(); double norm=f.norm();
            if(!Double.isFinite(norm)) throw new IOException("Non-finite contact force in "+PAIRS[pair]);
            sum.add(f); total+=norm; largest=Math.max(largest,norm); vertices++;
            if(norm>0) {
               Point3d p=entry.getKey().getWorldPoint();
               verticesLog.printf(Locale.ROOT,"%.12g,%s,0,%d,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g%n",
                  time,PAIRS[pair],entry.getKey().getIndex(),p.x,p.y,p.z,f.x,f.y,f.z);
            }
            if(pair>0 && norm>MIN_CONTACT_FORCE_MICRONEWTON)
               display.add(new Arrow(entry.getKey().getWorldPoint(),f));
         }
         boolean bearing=largest>MIN_CONTACT_FORCE_MICRONEWTON;
         if(intersects) {
            intersectionSamples[pair]++;
            if(firstIntersection[pair]<0) {
               firstIntersection[pair]=time;
               events.printf(Locale.ROOT,"%.12g,%s,first_sampled_mesh_intersection%n",time,PAIRS[pair]);
               System.out.printf(Locale.ROOT,"FSI INTERSECTION: %s at t=%.6f code%n",PAIRS[pair],time);
            }
         }
         if(bearing) {
            forceSamples[pair]++;
            if(firstForce[pair]<0) {
               firstForce[pair]=time;
               if(pair>0) firstVVForce=true;
               events.printf(Locale.ROOT,"%.12g,%s,first_sampled_load_bearing_contact%n",time,PAIRS[pair]);
               System.out.printf(Locale.ROOT,"FSI CONTACT FORCE: %s at t=%.6f code; maximum vertex force %.6g microN%n",PAIRS[pair],time,largest);
            }
         }
         maxVertexForce[pair]=Math.max(maxVertexForce[pair],largest);
         contacts.printf(Locale.ROOT,"%.12g,%s,%s,%s,%d,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%d,%d%n",
            time,PAIRS[pair],intersects,bearing,vertices,sum.x,sum.y,sum.z,sum.norm(),total,largest,evidence.handlers,evidence.withData);
      }
      display.sort((a,b)->Double.compare(b.force.norm(),a.force.norm()));
      if(display.size()>30) display=new ArrayList<Arrow>(display.subList(0,30));
      arrows=Collections.unmodifiableList(display);
      double[] minY={1e100,1e100,1e100,1e100},maxY={-1e100,-1e100,-1e100,-1e100};
      for(int f=0;f<4;f++) {
         int dynamic=0; double mean=0,minDy=1e100,maxDy=-1e100,peak=0;
         for(SurfaceLoadMap.NodeLoad n:loads.nodes) if(n.fold==f) {
            Point3d p=n.node.getPosition();
            minY[f]=Math.min(minY[f],p.y); maxY[f]=Math.max(maxY[f],p.y);
            peak=Math.max(peak,p.distance(n.initial));
            if(n.node.isDynamic()) {
               double dy=p.y-n.initial.y;
               dynamic++; mean+=dy; minDy=Math.min(minDy,dy); maxDy=Math.max(maxDy,dy);
            }
         }
         if(dynamic==0 || !Double.isFinite(peak)) throw new IOException("Invalid FEM descent record");
         descent.printf(Locale.ROOT,"%.12g,%d,%d,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g%n",
            time,f,dynamic,mean/dynamic,minDy,maxDy,minY[f],maxY[f],peak);
      }
      separation.printf(Locale.ROOT,"%.12g,%s,%.12g%n",time,PAIRS[1],minY[2]-maxY[0]);
      separation.printf(Locale.ROOT,"%.12g,%s,%.12g%n",time,PAIRS[2],minY[3]-maxY[1]);
      for(PrintWriter w:new PrintWriter[]{contacts,verticesLog,descent,separation,events}) {
         w.flush(); if(w.checkError()) throw new IOException("Could not write contact/descent record");
      }
      return firstVVForce;
   }

   void finish() throws IOException {
      try(PrintWriter w=writer("contact_summary.csv")) {
         w.println("pair,sampled_records,intersection_records,load_bearing_records,first_intersection_t_code,first_load_bearing_t_code,max_vertex_force_microN");
         for(int p=0;p<3;p++) w.printf(Locale.ROOT,"%s,%d,%d,%d,%s,%s,%.12g%n",PAIRS[p],records,intersectionSamples[p],forceSamples[p],
            firstIntersection[p]<0?"":String.format(Locale.ROOT,"%.12g",firstIntersection[p]),
            firstForce[p]<0?"":String.format(Locale.ROOT,"%.12g",firstForce[p]),maxVertexForce[p]);
         if(w.checkError()) throw new IOException("Could not write contact summary");
      }
      System.out.printf(Locale.ROOT,"FSI CONTACT SUMMARY: left=%s; right=%s%n",firstForce[1]>=0,firstForce[2]>=0);
   }

   RenderableComponentBase overlay() {
      return new RenderableComponentBase() {
         @Override public void render(Renderer renderer,int flags) {
            List<Arrow> current=arrows; double largest=0;
            for(Arrow a:current) largest=Math.max(largest,a.force.norm());
            if(largest<=0) return;
            double gain=1.4/largest; renderer.setColor(0.2f,1f,0.25f);
            for(Arrow a:current) renderer.drawArrow(new Point3d(a.point.x,a.point.y,7.35),
               new Point3d(a.point.x+gain*a.force.x,a.point.y+gain*a.force.y,7.35),0.025,true);
         }
         @Override public void updateBounds(Vector3d min,Vector3d max) {
            for(Arrow a:arrows) new Point3d(a.point.x,a.point.y,7.35).updateBounds(min,max);
         }
      };
   }

   private PrintWriter writer(String name) throws IOException {
      return new PrintWriter(Files.newBufferedWriter(output.resolve(name),StandardCharsets.UTF_8));
   }
   @Override public void close() { contacts.close(); verticesLog.close(); descent.close(); separation.close(); events.close(); }
}
