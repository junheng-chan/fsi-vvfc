package artisynth.models.vocVent.transientfsi;

import java.util.ArrayList;
import java.util.Arrays;

/** Slice actual moving surface triangles; scanline rasterisation of their union.
 * Pure array geometry: no FEM or fluid integration is performed here. */
final class MovingSlices {
   static final class Segment {
      final double[] a,b;
      Segment(double[] a,double[] b) { this.a=a; this.b=b; }
   }
   static final class Slice {
      final int[] material=new int[FluidFields.NX*FluidFields.NY];
      final float[] wall=new float[FluidFields.NX*FluidFields.NY*4];
      int fluidCells,uncovered,covered,changed;
      double minimumVocalGap=Double.POSITIVE_INFINITY;
      double maxWallLattice;
   }
   private final int[][][] triangles;
   MovingSlices(int[][][] triangles) { this.triangles=triangles; }

   @SuppressWarnings("unchecked")
   Slice[] build(double[][][] nodes,Slice[] previous) {
      Slice[] result=new Slice[3];
      for(int s=0;s<3;s++) {
         Slice slice=new Slice(); result[s]=slice;
         ArrayList<Segment>[] edges=new ArrayList[4];
         ArrayList<Segment> all=new ArrayList<Segment>();
         for(int f=0;f<4;f++) {
            edges[f]=section(nodes[f],triangles[f],FluidFields.Z[s]);
            if(edges[f].isEmpty()) throw new IllegalStateException("Missing section of fold "+f+" slice "+s);
            all.addAll(edges[f]);
         }
         int nx=FluidFields.NX,ny=FluidFields.NY;
         for(int j=0;j<ny;j++) {
            double yy=FluidFields.y(j);
            double left=Double.NEGATIVE_INFINITY,right=Double.POSITIVE_INFINITY;
            for(int i=0;i<nx;i++) slice.material[j*nx+i]=(i==0||i==nx-1||j==0||j==ny-1)?2:(j==1?5:(j==ny-2?6:1));
            for(int f=0;f<4;f++) {
               double[] intersections=new double[edges[f].size()]; int count=0;
               for(Segment e:edges[f]) {
                  double ya=e.a[1],yb=e.b[1];
                  if((ya<=yy && yb>yy)||(yb<=yy && ya>yy))
                     intersections[count++]=e.a[0]+(yy-ya)/(yb-ya)*(e.b[0]-e.a[0]);
               }
               Arrays.sort(intersections,0,count);
               if((count&1)!=0) throw new IllegalStateException("Open slice contour: fold "+f+" z="+FluidFields.Z[s]+" y="+yy);
               if(count>0 && f==0) left=intersections[count-1];
               if(count>0 && f==1) right=intersections[0];
               for(int k=0;k<count;k+=2) {
                  int from=Math.max(1,(int)Math.ceil((intersections[k]-FluidFields.X0-1e-9)/FluidFields.DX));
                  int to=Math.min(nx-2,(int)Math.floor((intersections[k+1]-FluidFields.X0+1e-9)/FluidFields.DX));
                  if(j==0||j==ny-1) continue;
                  for(int i=from;i<=to;i++) slice.material[j*nx+i]=2;
               }
            }
            if(Double.isFinite(left)&&Double.isFinite(right))
               slice.minimumVocalGap=Math.min(slice.minimumVocalGap,Math.max(0,right-left));
         }
         for(int j=0;j<ny;j++) for(int i=0;i<nx;i++) {
            int a=j*nx+i; boolean isFluid=FluidFields.fluid(slice.material[a]);
            if(isFluid) slice.fluidCells++;
            boolean oldFluid=previous==null?isFluid:FluidFields.fluid(previous[s].material[a]);
            if(isFluid!=oldFluid) { slice.changed++; if(isFluid)slice.uncovered++;else slice.covered++; }
            if(i==0||i==nx-1||j==0||j==ny-1) continue;
            boolean nearFluid=false;
            if(!isFluid) for(int dj=-1;dj<=1;dj++) for(int di=-1;di<=1;di++)
               if(FluidFields.fluid(slice.material[(j+dj)*nx+i+di])) nearFluid=true;
            if(!nearFluid && !(isFluid&&!oldFluid)) continue;
            double xx=FluidFields.x(i),yy=FluidFields.y(j),best=Double.POSITIVE_INFINITY,u=0,v=0;
            for(Segment e:all) {
               double dx=e.b[0]-e.a[0],dy=e.b[1]-e.a[1];
               double l=dx*dx+dy*dy;
               double t=l>1e-20?Math.max(0,Math.min(1,((xx-e.a[0])*dx+(yy-e.a[1])*dy)/l)):0;
               double ex=xx-e.a[0]-t*dx,ey=yy-e.a[1]-t*dy,dist=ex*ex+ey*ey;
               if(dist<best) { best=dist; u=e.a[3]+t*(e.b[3]-e.a[3]);v=e.a[4]+t*(e.b[4]-e.a[4]); }
            }
            slice.wall[4*a]=(float)(u*FluidFields.WALL_VELOCITY);
            slice.wall[4*a+1]=(float)(v*FluidFields.WALL_VELOCITY);
            slice.maxWallLattice=Math.max(slice.maxWallLattice,Math.hypot(slice.wall[4*a],slice.wall[4*a+1]));
         }
         if(!Double.isFinite(slice.minimumVocalGap)||slice.fluidCells==0)
            throw new IllegalStateException("Invalid moving slice "+s);
      }
      return result;
   }

   private static ArrayList<Segment> section(double[][] nodes,int[][] triangles,double z) {
      ArrayList<Segment> result=new ArrayList<Segment>();
      java.util.HashSet<String> seen=new java.util.HashSet<String>();
      for(int[] ids:triangles) {
         double[][] p={nodes[ids[0]],nodes[ids[1]],nodes[ids[2]]};
         double[] dz={p[0][2]-z,p[1][2]-z,p[2][2]-z};
         for(int k=0;k<3;k++) if(Math.abs(dz[k])<1e-9) dz[k]=0;
         if((dz[0]>0&&dz[1]>0&&dz[2]>0)||(dz[0]<0&&dz[1]<0&&dz[2]<0))continue;
         if(dz[0]==0&&dz[1]==0&&dz[2]==0)continue;
         ArrayList<double[]> hits=new ArrayList<double[]>();
         for(int i=0;i<3;i++) {
            int j=(i+1)%3;
            if(dz[i]==0)addUnique(hits,p[i].clone());
            if(dz[i]*dz[j]<0) {
               double t=-dz[i]/(dz[j]-dz[i]);double[] h=new double[6];
               for(int k=0;k<6;k++)h[k]=p[i][k]+t*(p[j][k]-p[i][k]);
               addUnique(hits,h);
            }
         }
         if(hits.size()==2) {
            double[] a=hits.get(0),b=hits.get(1);
            if(Math.hypot(a[0]-b[0],a[1]-b[1])>1e-9){
               long ax=Math.round(a[0]*1e8),ay=Math.round(a[1]*1e8),bx=Math.round(b[0]*1e8),by=Math.round(b[1]*1e8);
               String key=(ax<bx||(ax==bx&&ay<by))?ax+":"+ay+":"+bx+":"+by:bx+":"+by+":"+ax+":"+ay;
               if(seen.add(key))result.add(new Segment(a,b));
            }
         } else if(hits.size()>2)throw new IllegalStateException("Ambiguous surface section");
      }
      return result;
   }
   private static void addUnique(ArrayList<double[]> hits,double[] h) {
      for(double[] p:hits)if(Math.hypot(p[0]-h[0],p[1]-h[1])<1e-9)return;
      hits.add(h);
   }
}
