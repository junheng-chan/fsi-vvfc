package artisynth.models.vocVent.transientfsi;

import java.awt.Color;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Properties;

import artisynth.core.femmodels.FemModel3d;
import artisynth.core.femmodels.FemNode3d;
import artisynth.core.femmodels.FemModel.SurfaceRender;
import artisynth.core.mechmodels.CollisionBehavior;
import artisynth.core.mechmodels.MechModel;
import artisynth.core.modelbase.ControllerBase;
import artisynth.core.modelbase.MonitorBase;
import artisynth.core.modelbase.RenderableComponentBase;
import artisynth.core.modelbase.StepAdjustment;
import artisynth.core.workspace.DriverInterface;
import artisynth.core.workspace.RootModel;
import artisynth.models.vocVent.baseline.VocalFoldBuilder;
import artisynth.models.vocVent.baseline.VentFoldBuilder;
import maspack.geometry.Face;
import maspack.geometry.Vertex3d;
import maspack.matrix.Point3d;
import maspack.matrix.RigidTransform3d;
import maspack.matrix.Vector3d;
import maspack.render.Renderer;

/** First-order explicit partitioned pressure-only FSI using three independent
 * moving D2Q9 slices. A declared reduced-Re model, not validated phonation. */
public class VocVentTransientFSI extends RootModel {
   private final FemModel3d[] folds=new FemModel3d[4];
   private final FemNode3d[] reference=new FemNode3d[2];
   private final FluidFields pressure=new FluidFields();
   private SurfaceLoadMap map;
   private MovingSlices geometry;
   private MovingSlices.Slice[] slices,initialSlices;
   private GpuCoupledSolver gpu;
   private ContactRecorder contact;
   private PrintWriter summary,coupling,snapshots,forces;
   private Path output;
   private double end,interval,ramp,targetPa,gravityY;
   private double fluidCodeTime,lastFEM=-1,commandT0,commandT1;
   private int steps,exchanges;
   private boolean finished,feedback=true;
   private long wallStart;
   private double nextSnapshot=.25;
   private volatile float[][] displayMacro;
   private volatile MovingSlices.Slice[] displaySlices;

   @Override public void build(String[] args) throws IOException {
      super.build(args);
      Properties config=new Properties();
      try(java.io.InputStream in=Files.newInputStream(directory().resolve("run.properties"))){config.load(in);}
      end=number(config,"end_code");interval=number(config,"coupling_interval_code");
      ramp=number(config,"ramp_code");targetPa=number(config,"pressure_difference_Pa");
      gravityY=number(config,"gravity_y_code");
      if(args!=null)for(String arg:args)if(arg.equals("--one-way"))feedback=false;
      if(end<=0||interval<=0||interval>.00500001||ramp<=0||targetPa<=0||targetPa>100)
         throw new IOException("Invalid or unsupported prototype parameters");
      double latticeInterval=interval*FluidFields.CODE_SECOND/FluidFields.DT;
      if(Math.abs(latticeInterval-Math.rint(latticeInterval))>1e-8)
         throw new IOException("Coupling interval must contain an integer number of lattice steps");
      setMaxStepSize(interval);
      MechModel mech=new MechModel("mech");mech.setGravity(0,gravityY,0);mech.setMaxStepSize(interval);addModel(mech);
      VocalFoldBuilder vb=new VocalFoldBuilder();VentFoldBuilder eb=new VentFoldBuilder();
      folds[0]=vb.buildFem(false);folds[1]=vb.buildFem(true);folds[2]=eb.buildFem(false);folds[3]=eb.buildFem(true);
      for(int f=0;f<4;f++){
         for(FemNode3d n:folds[f].getNodes())if(Math.abs(n.getPosition().x)<1e-7)n.setDynamic(false);
         folds[f].transformGeometry(new RigidTransform3d((f%2==0?-1:1)*(f<2?7.8:10.8),f<2?0:.5,0));
         folds[f].setGravity(0,gravityY,0);folds[f].setAbortOnInvertedElements(true);
         folds[f].setSurfaceRendering(SurfaceRender.Shaded);
         RenderPropsHelper.colour(folds[f],f<2?new Color(249,212,160):new Color(249,150,140));
         mech.addModel(folds[f]);
      }
      mech.setCollisionBehavior(folds[0],folds[1],new CollisionBehavior(true,.5));
      mech.setCollisionBehavior(folds[0],folds[2],new CollisionBehavior(true,0));
      mech.setCollisionBehavior(folds[1],folds[3],new CollisionBehavior(true,0));
      geometry=new MovingSlices(topology());slices=geometry.build(coordinates(false),null);initialSlices=slices;
      pressure.set(slices,null);displaySlices=slices;
      String kind=feedback?"coupled":"oneway";
      output=Paths.get("transient_fsi_results","run_"+new SimpleDateFormat("yyyyMMdd_HHmmss_SSS").format(new Date())+"_"+kind).toAbsolutePath();
      Files.createDirectories(output);
      try(PrintWriter q=writer("quadrature_initial.csv");PrintWriter t=writer("surface_triangles.csv");PrintWriter ch=writer("mapping_initial.csv")){
         map=new SurfaceLoadMap(folds,pressure,q,t,ch);
      }
      map.referenceGeometry=!feedback;
      reference[0]=chooseReference(folds[0],true);reference[1]=chooseReference(folds[1],false);
      contact=new ContactRecorder(mech,folds,map,output);
      summary=writer("summary.csv");coupling=writer("coupling.csv");snapshots=writer("node_snapshots.csv");forces=writer("pressure_forces.csv");
      summary.println("t_code,t_ms_declared,exchange,fluid_steps,fluid_code_time,left_ref_node,right_ref_node,left_x_mm,left_y_mm,left_z_mm,right_x_mm,right_y_mm,right_z_mm,left_dx_mm,left_dy_mm,left_dz_mm,right_dx_mm,right_dy_mm,right_dz_mm,left_vx_code,left_vy_code,right_vx_code,right_vy_code,reference_x_separation_mm,vocal_left_max_displacement_mm,vocal_right_max_displacement_mm,ventricular_left_max_displacement_mm,ventricular_right_max_displacement_mm");
      coupling.println("geometry_t_code,fluid_t_code,exchange,slice,lbm_steps,fluid_cells,changed_cells,uncovered_cells,covered_cells,min_vocal_gap_mm,wall_speed_max_lattice,rho_min,rho_max,max_Mach,min_population,total_mass_lattice,inlet_flux_lattice,outlet_flux_lattice,inlet_Q_ml_s,outlet_Q_ml_s,mean_inlet_pressure_Pa,mean_outlet_pressure_Pa,pressure_rms_change_Pa,estimated_remap_mass_lattice");
      snapshots.println("t_code,fold,node,x_mm,y_mm,z_mm,dx_mm,dy_mm,dz_mm,vx_code,vy_code,vz_code,fx_microN,fy_microN,fz_microN");
      forces.println("geometry_t_code,fluid_t_code,exchange,fold,candidate_area_mm2,sampled_area_mm2,resultant_fx_microN,resultant_fy_microN,resultant_fz_microN");
      writeInitial();writeMetadata();record(0);contact.record(0);snapshot(0);
      addController(new ControllerBase(){@Override public void apply(double t0,double t1){
         if(finished)return;
         try{exchange(t0,t1);}catch(IOException|RuntimeException e){fail(e,t0);throw new IllegalStateException("FSI exchange stopped",e);}
      }});
      addMonitor(new MonitorBase(){@Override public void apply(double t0,double t1){
         if(finished)return;
         try{
            double peak=record(t1);boolean first=contact.record(t1);
            if(peak>1.5)throw new IOException("Maximum displacement exceeded 1.5 mm");
            if(first||t1>=nextSnapshot-1e-9||t1>=end-1e-9){snapshot(t1);if(t1>=nextSnapshot-1e-9)nextSnapshot+=.25;}
            if(t1>=end-1e-9){
               saveFields("final",commandT0,t1);
               contact.finish();finished=true;closeLogs();setStopRequest(true);
               Files.write(output.resolve("TRANSIENT_FSI_COMPLETE.txt"),("Completed "+exchanges+" exchanges. feedback="+feedback+". Reduced-Re pressure-only multi-slice model; not validated phonation.\n").getBytes(StandardCharsets.UTF_8));
               System.out.println("TRANSIENT FSI COMPLETE: "+output);
            }
         }catch(IOException|RuntimeException e){fail(e,t1);throw new IllegalStateException("FSI recording stopped",e);}
      }});
      addRenderable(new FlowPlane());addRenderable(contact.overlay());addRenderable(new PressureArrows());
      System.out.printf(Locale.ROOT,"FSI MODE: %s; end %.3f code; %.6f code/exchange; approximately %d exchanges%n",kind,end,interval,Math.round(end/interval));
      System.out.printf(Locale.ROOT,"FSI UNITS: 1 code = %.6g s; fluid dt %.6g s; %.0f lattice steps/exchange%n",FluidFields.CODE_SECOND,FluidFields.DT,latticeInterval);
      System.out.printf(Locale.ROOT,"FSI FLUID: density %.3f kg/m3; effective viscosity %.9g m2/s; target %.1f Pa%n",FluidFields.DENSITY,FluidFields.VISCOSITY,targetPa);
      System.out.printf(Locale.ROOT,"FSI GRAVITY: %.6f code = %.6f m/s2 under declared units; legacy parameter, not calibrated Earth gravity%n",gravityY,10*gravityY);
      for(int s=0;s<3;s++)System.out.printf(Locale.ROOT,"FSI INITIAL slice=%d: fluid=%d; vocal gap %.6f mm%n",s+1,slices[s].fluidCells,slices[s].minimumVocalGap);
      System.out.println("FSI READY: loading is paused; Play starts the main coupled run, including the initial checks.");
      System.out.println("FSI output: "+output);
   }

   @Override public void attach(DriverInterface driver){super.attach(driver);
      int[][] materials={slices[0].material,slices[1].material,slices[2].material};
      gpu=new GpuCoupledSolver(FluidFields.NX,FluidFields.NY,materials,(float)FluidFields.TAU,
         (float)(3*targetPa/FluidFields.PRESSURE),(int)Math.round(ramp*FluidFields.CODE_SECOND/FluidFields.DT));
      System.out.println("FSI GPU READY: shaders compiled; zero fluid steps; Play starts the run.");
   }
   @Override public StepAdjustment advance(double t0,double t1,int flags){
      try{return super.advance(t0,t1,flags);}catch(RuntimeException e){if(!finished)fail(e,t0);throw e;}
   }
   private void exchange(double t0,double t1) throws IOException {
      if(gpu==null)throw new IOException("GPU not attached");
      if(Math.abs(t0-fluidCodeTime)>1e-8 || (lastFEM>=0&&Math.abs(t0-lastFEM)>1e-8))throw new IOException("Unsupported rewind or unsynchronised coupling time");
      if(wallStart==0)wallStart=System.nanoTime();
      double travel=0;
      for(FemModel3d f:folds)for(FemNode3d n:f.getNodes())travel=Math.max(travel,n.getVelocity().norm()*(t1-t0));
      if(travel>FluidFields.DX*.5)throw new IOException("Wall would move more than half a fluid cell per coupling interval");
      MovingSlices.Slice[] previous=slices;
      MovingSlices.Slice[] next=feedback?geometry.build(coordinates(false),slices):initialSlices;
      float[][] old=pressure.macro;
      double[] remap=estimateRemap(slices,next,old);
      int count=(int)Math.round((t1-t0)*FluidFields.CODE_SECOND/FluidFields.DT);
      if(count<1||Math.abs(count*FluidFields.DT-(t1-t0)*FluidFields.CODE_SECOND)>1e-11)throw new IOException("Fluid/mechanical time-step mismatch");
      float[][] macro=gpu.advance(steps,count,next);steps+=count;exchanges++;fluidCodeTime=t1;
      slices=next;pressure.set(next,macro);commandT0=t0;commandT1=t1;
      for(int s=0;s<3;s++)recordFluid(s,t0,t1,old,remap[s],previous);
      if(t1>=end-1e-9){
         try(PrintWriter q=writer("quadrature_final.csv");PrintWriter ch=writer("mapping_final.csv")){map.update(pressure,q,null,ch,false);}
      }else map.update(pressure,null,null,null,false);
      for(SurfaceLoadMap.NodeLoad nl:map.nodes)nl.node.setExternalForce(nl.force);
      for(int f=0;f<4;f++){
         double area=0,sampled=0;for(int s=0;s<3;s++){area+=map.candidateArea[f][s];sampled+=map.sampledArea[f][s];}
         Vector3d v=map.integratedForce[f];forces.printf(Locale.ROOT,"%.12g,%.12g,%d,%d,%.12g,%.12g,%.12g,%.12g,%.12g%n",t0,t1,exchanges,f,area,sampled,v.x,v.y,v.z);
      }
      flush(coupling);flush(forces);displaySlices=slices;displayMacro=macro;
   }
   private void recordFluid(int s,double t0,double t1,float[][] old,double remap,MovingSlices.Slice[] previous) throws IOException {
      float[] v=pressure.macro[s];int[] m=slices[s].material;
      double min=Double.POSITIVE_INFINITY,max=0,mach=0,pop=Double.POSITIVE_INFINITY,mass=0,qi=0,qo=0,pi=0,po=0,diff=0;int ni=0,no=0,nd=0;
      for(int a=0;a<m.length;a++)if(FluidFields.fluid(m[a])){
         double rho=v[4*a],u=v[4*a+1],vv=v[4*a+2],mn=v[4*a+3];
         if(!Double.isFinite(rho+u+vv+mn))throw new IOException("Non-finite fluid value");
         min=Math.min(min,rho);max=Math.max(max,rho);mass+=rho;pop=Math.min(pop,mn);mach=Math.max(mach,Math.hypot(u,vv)*Math.sqrt(3));
         if(m[a]==5){qi+=rho*vv;pi+=(rho-1)*FluidFields.PRESSURE/3;ni++;}
         if(m[a]==6){qo+=rho*vv;po+=(rho-1)*FluidFields.PRESSURE/3;no++;}
         if(old!=null&&FluidFields.fluid(previous[s].material[a])){double dp=(rho-old[s][4*a])*FluidFields.PRESSURE/3;diff+=dp*dp;nd++;}
      }
      if(ni==0||no==0||min<.8||max>1.2||mach>.20||pop< -1e-7)throw new IOException("Fluid guard: slice="+s+" rho="+min+".."+max+" Mach="+mach+" population="+pop);
      double conversion=FluidFields.VELOCITY*FluidFields.DX*.001*(14./3*.001)*1e6;
      // Q uses velocity, not density-weighted mass flux.
      double vi=0,vo=0;for(int a=0;a<m.length;a++){if(m[a]==5)vi+=v[4*a+2];if(m[a]==6)vo+=v[4*a+2];}
      coupling.printf(Locale.ROOT,"%.12g,%.12g,%d,%d,%d,%d,%d,%d,%d,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g%n",
         t0,t1,exchanges,s+1,steps,slices[s].fluidCells,slices[s].changed,slices[s].uncovered,slices[s].covered,slices[s].minimumVocalGap,slices[s].maxWallLattice,min,max,mach,pop,mass,qi,qo,vi*conversion,vo*conversion,pi/ni,po/no,nd>0?Math.sqrt(diff/nd):0,remap);
   }
   private double[] estimateRemap(MovingSlices.Slice[] previous,MovingSlices.Slice[] current,float[][] old){
      double[] result=new double[3];if(old==null)return result;
      int nx=FluidFields.NX,ny=FluidFields.NY;
      for(int s=0;s<3;s++)for(int a=0;a<nx*ny;a++){
         boolean before=FluidFields.fluid(previous[s].material[a]),after=FluidFields.fluid(current[s].material[a]);
         if(before&&!after)result[s]-=old[s][4*a];
         if(!before&&after){double rho=0;int n=0,i=a%nx,j=a/nx;
            for(int dj=-1;dj<=1;dj++)for(int di=-1;di<=1;di++)if(di!=0||dj!=0){int ii=i+di,jj=j+dj;if(ii<0||ii>=nx||jj<0||jj>=ny)continue;int b=jj*nx+ii;
               if(FluidFields.fluid(previous[s].material[b])&&FluidFields.fluid(current[s].material[b])){rho+=old[s][4*b];n++;}}
            result[s]+=n>0?rho/n:1;
         }
      }return result;
   }
   private double record(double time) throws IOException {
      double[] peak=new double[4];
      for(SurfaceLoadMap.NodeLoad n:map.nodes){double v=n.node.getPosition().distance(n.initial);if(!Double.isFinite(v))throw new IOException("Invalid FEM displacement");peak[n.fold]=Math.max(peak[n.fold],v);}
      Point3d a=reference[0].getPosition(),b=reference[1].getPosition();Vector3d da=new Vector3d(),db=new Vector3d();
      da.sub(a,map.byNode.get(reference[0]).initial);db.sub(b,map.byNode.get(reference[1]).initial);
      Vector3d va=reference[0].getVelocity(),vb=reference[1].getVelocity();
      summary.printf(Locale.ROOT,"%.12g,%.12g,%d,%d,%.12g,%d,%d,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g%n",
         time,1000*FluidFields.CODE_SECOND*time,exchanges,steps,fluidCodeTime,reference[0].getNumber(),reference[1].getNumber(),a.x,a.y,a.z,b.x,b.y,b.z,da.x,da.y,da.z,db.x,db.y,db.z,va.x,va.y,vb.x,vb.y,b.x-a.x,peak[0],peak[1],peak[2],peak[3]);
      flush(summary);
      if((int)Math.floor(time*10+1e-8)>(int)Math.floor(lastFEM*10+1e-8))System.out.printf(Locale.ROOT,"FSI t=%.4f/%.3f code; exchange=%d; fluid steps=%d; maximum displacement=%.6f mm; elapsed %.1f s%n",time,end,exchanges,steps,Math.max(Math.max(peak[0],peak[1]),Math.max(peak[2],peak[3])),wallStart==0?0:(System.nanoTime()-wallStart)/1e9);
      lastFEM=time;return Math.max(Math.max(peak[0],peak[1]),Math.max(peak[2],peak[3]));
   }
   private void snapshot(double time) throws IOException {
      for(SurfaceLoadMap.NodeLoad n:map.nodes){Point3d p=n.node.getPosition();Vector3d v=n.node.getVelocity();
         snapshots.printf(Locale.ROOT,"%.12g,%d,%d,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g%n",time,n.fold,n.node.getNumber(),p.x,p.y,p.z,p.x-n.initial.x,p.y-n.initial.y,p.z-n.initial.z,v.x,v.y,v.z,n.force.x,n.force.y,n.force.z);}
      flush(snapshots);
   }
   private void saveFields(String name,double geometryTime,double fluidTime) throws IOException {
      if(pressure.macro==null)return;
      for(int s=0;s<3;s++)try(PrintWriter w=writer("slice_"+(s+1)+"_"+name+".csv")){
         w.println("geometry_t_code,fluid_t_code,x_mm,y_mm,z_mm,material,rho,ux_lattice,uy_lattice,pressure_Pa,speed_m_s");
         for(int a=0;a<FluidFields.NX*FluidFields.NY;a++){
            float[] v=pressure.macro[s];w.printf(Locale.ROOT,"%.12g,%.12g,%.12g,%.12g,%.12g,%d,%.9g,%.9g,%.9g,%.12g,%.12g%n",geometryTime,fluidTime,FluidFields.x(a%FluidFields.NX),FluidFields.y(a/FluidFields.NX),FluidFields.Z[s],slices[s].material[a],v[4*a],v[4*a+1],v[4*a+2],(v[4*a]-1)*FluidFields.PRESSURE/3,Math.hypot(v[4*a+1],v[4*a+2])*FluidFields.VELOCITY);
         }if(w.checkError())throw new IOException("Cannot write fluid field");
      }
   }
   private int[][][] topology(){int[][][] result=new int[4][][];
      for(int f=0;f<4;f++){ArrayList<int[]> faces=new ArrayList<int[]>();for(Face face:folds[f].getSurfaceMesh().getFaces()){
         Vertex3d[] v=face.getVertices();if(v.length!=3)throw new IllegalStateException("Nontriangular surface");
         faces.add(new int[]{folds[f].getSurfaceNode(v[0]).getNumber(),folds[f].getSurfaceNode(v[1]).getNumber(),folds[f].getSurfaceNode(v[2]).getNumber()});}
         result[f]=faces.toArray(new int[faces.size()][]);
      }return result;
   }
   private double[][][] coordinates(boolean zeroVelocity){double[][][] result=new double[4][][];
      for(int f=0;f<4;f++){result[f]=new double[folds[f].numNodes()][];for(FemNode3d n:folds[f].getNodes()){
         Point3d p=n.getPosition();Vector3d v=n.getVelocity();int id=n.getNumber();if(id<0||id>=result[f].length)throw new IllegalStateException("Noncontiguous node numbering");
         result[f][id]=new double[]{p.x,p.y,p.z,zeroVelocity?0:v.x,zeroVelocity?0:v.y,zeroVelocity?0:v.z};}
      }return result;
   }
   private FemNode3d chooseReference(FemModel3d f,boolean left){double edge=left? -1e30:1e30;for(FemNode3d n:f.getNodes())edge=left?Math.max(edge,n.getPosition().x):Math.min(edge,n.getPosition().x);
      FemNode3d best=null;for(FemNode3d n:f.getNodes())if(Math.abs(n.getPosition().x-edge)<.05){if(best==null){best=n;continue;}Point3d p=n.getPosition(),b=best.getPosition();double dz=Math.abs(p.z)-Math.abs(b.z);if(dz< -1e-9||(Math.abs(dz)<1e-9&&(left?p.x>b.x:p.x<b.x)))best=n;}return best;
   }
   private void writeInitial() throws IOException {try(PrintWriter w=writer("nodes_initial.csv")){
      w.println("fold,node,dynamic,x_mm,y_mm,z_mm");for(SurfaceLoadMap.NodeLoad n:map.nodes)w.printf(Locale.ROOT,"%d,%d,%s,%.12g,%.12g,%.12g%n",n.fold,n.node.getNumber(),n.node.isDynamic(),n.initial.x,n.initial.y,n.initial.z);
   }}
   private void writeMetadata() throws IOException {try(PrintWriter w=writer("metadata.txt")){
      w.println("kind="+(feedback?"explicit partitioned moving-slice pressure-only FSI":"matched one-way reference-geometry pressure loading"));
      w.println("feedback_enabled="+feedback);w.println("nx=314; ny=402; dx_mm=0.05; three independent coronal slices, not a 3D airflow solver");
      w.println("initial_gaps_mm=vocal 0.98; ventricular 7; vocal-ventricular bounding clearance approximately 0.514");
      w.println("code_time_seconds="+FluidFields.CODE_SECOND);w.println("fluid_dt_seconds="+FluidFields.DT);w.println("coupling_interval_code="+interval);w.println("end_code="+end);
      w.println("fluid_density_kg_m3="+FluidFields.DENSITY);w.println("fluid_effective_kinematic_viscosity_m2_s="+FluidFields.VISCOSITY);
      w.println("effective_viscosity_is_elevated_not_physical_air=true; reduced-Re exploratory model");
      w.println("velocity_conversion_m_s_per_lattice="+FluidFields.VELOCITY);w.println("pressure_conversion_Pa_per_lattice="+FluidFields.PRESSURE);
      w.println("revision=2; fluid time refinement after Mach guard in first main run");
      w.println("pressure_rule="+FluidFields.PRESSURE+"*(rho-1)/3 Pa gauge; constant scale, no per-frame normalisation");
      w.println("inlet_pressure_difference_Pa="+targetPa);w.println("pressure_ramp_code="+ramp);w.println("outlet_density=1; inlet_final_density="+(1+3*targetPa/FluidFields.PRESSURE));
      w.println("gravity_y_code="+gravityY);w.println("gravity_m_s2_under_adopted_units="+(10*gravityY));w.println("historical_physical_units_unverified=true; gravity restores the legacy parameter, not Earth gravity calibration");
      w.println("mechanical_units=mm, Pa, microN, 0.01 s/code; unchanged tissue builders and lateral fixation; AP ends free");
      w.println("fluid_state=persistent populations, initially rho=1 and zero velocity; no steady-flow preload");
      w.println("FEM_state=persistent node positions and velocities; rest material configuration preserved; no mechanical restart between exchanges");
      w.println("coupling_order=geometry/velocity at t0; advance fluid to t1 with fixed t0 mask and moving-wall velocity; integrate pressure on t0 surface; advance FEM to t1");
      w.println("first_order_partitioned_lag=true; fluid masks saved with geometry_t_code, FEM snapshots with t_code");
      w.println("wall_rule=halfway velocity bounce-back; wall velocities interpolated from nearest section segment; no motion normal to the 2D slice");
      w.println("cell_conversion=newly fluid cells refilled with equilibrium from retained fluid neighbours; not strictly mass conserving; estimated remap mass logged separately");
      w.println("surface_pressure_loading=current outward normals/areas, clipped to three AP bands, barycentric nodal weights; buried unsampled contact faces receive no fluid pressure");
      w.println("oneway_mode=initial fluid geometry and zero wall velocity; pressure loads evaluated on the initial surface as reference-configuration loads");
      w.println("shear_force_transfer=false; unmodelled spanwise flow and pressure-only structural loading limit energy/momentum consistency");
      w.println("gap_measure=minimum horizontal vocal gap on each coronal raster; not a 3D glottal area");
      w.println("Q_measure=sum of slice fluxes times representative AP band depth; multi-slice volume-flow approximation");
      w.println("contact_recording=legacy inContact bypassed; recorded geometry and force data may lag an integration step");
      w.println("display=mid-coronal speed, blue to red, ceiling 10 m/s; front-projected plane z=7.2; force-arrow lengths scaled per frame");
      w.println("guards=finite fluid/FEM; rho 0.8..1.2; Mach <=0.20; postcollision populations >=-1e-7; nodal displacement <=1.5mm; predicted wall travel <=0.5dx/exchange; exact fluid/structure clock agreement");
      w.println("provenance=Yong FEM builders; separate AI-assisted D2Q9 diagnostic extended for moving boundaries; not unchanged Kummerlaender/Moisik code");
      w.println("validation=compile and geometry/input checks only before launch; live GPU/FEM behaviour must be assessed from this main run");
   }}
   private static Path directory() throws IOException {try{return Paths.get(VocVentTransientFSI.class.getProtectionDomain().getCodeSource().getLocation().toURI()).getParent();}catch(Exception e){throw new IOException(e);}}
   private static double number(Properties p,String name) throws IOException {try{double x=Double.parseDouble(p.getProperty(name));if(Double.isFinite(x))return x;}catch(RuntimeException ignored){}throw new IOException("Invalid property "+name);}
   private PrintWriter writer(String name) throws IOException {return new PrintWriter(Files.newBufferedWriter(output.resolve(name),StandardCharsets.UTF_8));}
   private static void flush(PrintWriter w) throws IOException {w.flush();if(w.checkError())throw new IOException("Cannot write FSI output");}
   private void closeLogs(){if(summary!=null)summary.close();if(coupling!=null)coupling.close();if(snapshots!=null)snapshots.close();if(forces!=null)forces.close();if(contact!=null)contact.close();}
   private void fail(Exception e,double time){if(finished)return;finished=true;setStopRequest(true);
      try{if(snapshots!=null)snapshot(Math.max(0,time));if(pressure.macro!=null)saveFields("stopped",commandT0,fluidCodeTime);if(contact!=null)contact.finish();}catch(Exception ignored){}
      closeLogs();try{Files.write(output.resolve("TRANSIENT_FSI_FAILED.txt"),e.toString().getBytes(StandardCharsets.UTF_8));}catch(Exception ignored){}
      System.err.println("TRANSIENT FSI STOPPED: "+e);System.err.println("FSI output: "+output);e.printStackTrace();
   }
   @Override public void detach(DriverInterface driver){closeLogs();if(gpu!=null){gpu.close();gpu=null;}super.detach(driver);}
   private static final class RenderPropsHelper {static void colour(FemModel3d f,Color c){maspack.render.RenderProps.setFaceColor(f,c);maspack.render.RenderProps.setAlpha(f,1);maspack.render.RenderProps.setLineWidth(f,0);}}
   private final class FlowPlane extends RenderableComponentBase {
      @Override public void render(Renderer r,int flags){MovingSlices.Slice[] m=displaySlices;float[][] v=displayMacro;if(m==null)return;
         r.setPointSize(3);r.beginDraw(Renderer.DrawMode.POINTS);
         for(int j=1;j<FluidFields.NY-1;j+=2)for(int i=1;i<FluidFields.NX-1;i+=2){int a=j*FluidFields.NX+i;if(!FluidFields.fluid(m[1].material[a]))continue;
            double speed=v==null?0:Math.hypot(v[1][4*a+1],v[1][4*a+2]);float f=(float)Math.min(1,speed/.10);
            r.setColor(f,.15f*(1-f),1-f);r.addVertex(FluidFields.x(i),FluidFields.y(j),7.2);
         }r.endDraw();
      }
      @Override public void updateBounds(Vector3d min,Vector3d max){new Point3d(-8,-10,7.2).updateBounds(min,max);new Point3d(8,10,7.2).updateBounds(min,max);}
   }
   private final class PressureArrows extends RenderableComponentBase {
      @Override public void render(Renderer r,int flags){if(map==null)return;double largest=0;for(SurfaceLoadMap.NodeLoad n:map.nodes)if(n.node.isDynamic()&&Math.abs(n.initial.z)<1)largest=Math.max(largest,n.force.norm());if(largest<=0)return;
         r.setColor(.1f,.9f,1);int shown=0;for(SurfaceLoadMap.NodeLoad n:map.nodes)if(n.node.isDynamic()&&Math.abs(n.initial.z)<1&&n.force.norm()>.1*largest){if(shown++%3!=0)continue;Point3d p=n.node.getPosition();double gain=1.2/largest;r.drawArrow(new Point3d(p.x,p.y,7.4),new Point3d(p.x+gain*n.force.x,p.y+gain*n.force.y,7.4),.02,true);}
      }
   }
}
